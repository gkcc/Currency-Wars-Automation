"""Reproducibly assemble this fixed patch, without reading a worktree."""
from pathlib import Path
import difflib
import json
import re
ROOT = Path(__file__).resolve().parent

def text(path):
    return (ROOT/path).read_text(encoding='utf-8')

insert_old = '''def _prepare_recovery_record(run, control, records, pending, evidence):
    """Retain a failed read-only report before an explicit NEW current review.

'''
call_old = '''                intent = validate_reward_recovery(recovery, request, binding, checkpoint_id, pending)
                _prepare_recovery_record(run, control, records, pending, recovery)
            if guide is not None:
'''
call_new = '''                intent = validate_reward_recovery(recovery, request, binding, checkpoint_id, pending)
                _check_recovery_retry(run, owner, control, records, pending, recovery,
                                      request, binding, existing)
                _prepare_recovery_record(run, control, records, pending, recovery)
            if guide is not None:
'''
replacements = [
    dict(path='tools/currency_wars_manual_steps.py', old=insert_old,
         new=text('fragments/recovery_helper.py') + insert_old, line=294),
    dict(path='tools/currency_wars_manual_steps.py', old=call_old, new=call_new, line=415),
    dict(path='tools/currency_wars_runner.py', old=text('fragments/navigation_check.old.py'),
         new=text('fragments/navigation_check.new.py'), line=5788),
]
(ROOT/'replacements.json').write_text(json.dumps(replacements,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
parts=[]
for path in dict.fromkeys(r['path'] for r in replacements):
    parts.append(f'diff --git a/{path} b/{path}\n--- a/{path}\n+++ b/{path}\n')
    offset=0
    for r in [r for r in replacements if r['path']==path]:
        diff=list(difflib.unified_diff(r['old'].splitlines(keepends=True),r['new'].splitlines(keepends=True),n=3))[2:]
        def location(match):
            a,ac,b,bc=match.groups()
            return f'@@ -{int(a)+r["line"]-1}{ac or ""} +{int(b)+r["line"]-1+offset}{bc or ""} @@'
        for line in diff:
            if line.startswith('@@'):
                line=re.sub(r'@@ -(\d+)(,\d+)? \+(\d+)(,\d+)? @@',location,line)
            parts.append(line)
        offset+=len(r['new'].splitlines())-len(r['old'].splitlines())
for path in sorted((ROOT/'files').rglob('*')):
    if path.is_file():
        relative=path.relative_to(ROOT/'files').as_posix()
        parts.append(f'diff --git a/{relative} b/{relative}\nnew file mode 100644\n')
        parts.extend(difflib.unified_diff([],path.read_text(encoding='utf-8').splitlines(keepends=True),
                                         fromfile='/dev/null',tofile='b/'+relative,n=3))
(ROOT/'PR30_retry_obligations.patch').write_text(''.join(parts),encoding='utf-8')
