"""Strict offline application of the supplied fixed patch to isolated PR30 bytes.

No fetching, installing, importing project code, starting processes from the
project, changing READY or writing to an unspecified worktree. git apply is
first exercised on temporary copies of the exact affected input files.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

PACKAGE = Path(__file__).resolve().parent
PARENT = '51798ecf7a62d8f778a799c130fc111fc2f836a5'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(mapping):
    return sha(json.dumps(mapping, sort_keys=True, separators=(',', ':')).encode())


def run_git(args, root):
    return subprocess.run(['git', *args], cwd=root, check=True, capture_output=True, text=True, timeout=30)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check', action='store_true')
    mode.add_argument('--apply', action='store_true')
    parser.add_argument('--isolated-review-directory', action='store_true', required=True,
                        help='Explicitly confirm this is NOT the production worktree')
    args = parser.parse_args()
    if args.report.exists():
        parser.error('Report already exists; use a fresh output path before applying')
    root = args.repo.resolve()
    patch_path = PACKAGE/'PR30_retry_obligations.patch'
    report = dict(parent_commit=PARENT, published_commit=None, patch_sha256=sha(patch_path.read_bytes()),
                  repository_modified=False, production_installed=False, focused_consumer_tests_run=False)
    try:
        package_map = json.loads((PACKAGE/'SHA256SUMS.json').read_text(encoding='utf-8'))
        for name, expected in package_map.items():
            if sha((PACKAGE/name).read_bytes()) != expected:
                raise ValueError('Package bytes differ: ' + name)
        metadata = json.loads((PACKAGE/'references/PARENT_BYTES.json').read_text(encoding='utf-8'))
        if metadata['parent_commit'] != PARENT:
            raise ValueError('Unexpected parent binding')
        try:
            head = run_git(['rev-parse', 'HEAD'], root).stdout.strip()
        except (subprocess.CalledProcessError, OSError):
            head = None
        report['input_checkout_head'] = head
        if head is not None and head != PARENT:
            raise ValueError('Expected sole PR30 parent checkout, not ' + head)
        expected = {**metadata['source_sha256'], **metadata['artifact_sha256']}
        observed = {}
        for name, expected_sha in expected.items():
            path = root/name
            if path.resolve().parent != path.parent.resolve() or not path.resolve().is_relative_to(root):
                raise ValueError('Input path escaped isolated tree: ' + name)
            observed[name] = sha(path.read_bytes())
            if observed[name] != expected_sha:
                raise ValueError('Not the frozen PR30 bytes: ' + name)
        replacements = json.loads((PACKAGE/'replacements.json').read_text(encoding='utf-8'))
        proposed, originals = {}, {}
        for rule in replacements:
            name = rule['path']
            if name not in originals:
                originals[name] = (root/name).read_bytes()
                proposed[name] = originals[name].decode('utf-8')
            if proposed[name].count(rule['old']) != 1:
                raise ValueError('Exact frozen replacement did not match once: ' + name)
            proposed[name] = proposed[name].replace(rule['old'], rule['new'], 1)
        for path in (PACKAGE/'files').rglob('*'):
            if path.is_file():
                name = path.relative_to(PACKAGE/'files').as_posix()
                if (root/name).exists() or name in proposed:
                    raise ValueError('New candidate path already exists: ' + name)
                proposed[name] = path.read_text(encoding='utf-8')
        for name, text in proposed.items():
            if name.endswith('.py'):
                compile(text, name, 'exec')  # Compile only; do not import or run it.
        with tempfile.TemporaryDirectory(prefix='cw-pr30-strict-apply-') as temporary:
            staged = Path(temporary)
            for name, data in originals.items():
                path = staged/name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
            run_git(['apply', '--check', '--whitespace=error', str(patch_path)], staged)
            run_git(['apply', '--whitespace=error', str(patch_path)], staged)
            for name, text in proposed.items():
                if (staged/name).read_bytes() != text.encode('utf-8'):
                    raise ValueError('git apply differs from fixed source replacement: ' + name)
        report.update(git_apply_check_on_full_original_files=True, proposed_python_compiles=True,
                      changed_file_sha256={name: sha(text.encode('utf-8')) for name, text in sorted(proposed.items())})
        candidate_sources = dict(metadata['source_sha256'])
        for name, text in proposed.items():
            if name.endswith('.py'):
                candidate_sources[name] = sha(text.encode('utf-8'))
        report.update(source_file_count=len(candidate_sources), source_sha256=dict(sorted(candidate_sources.items())),
                      source_set_sha256=digest(candidate_sources),
                      artifact_sha256=metadata['artifact_sha256'], artifact_file_count=len(metadata['artifact_sha256']))
        if args.apply:
            # Recheck all input bytes immediately before any write. Never
            # overwrite caller changes, publish, stage or touch Git history.
            if any(sha((root/name).read_bytes()) != value for name, value in observed.items()):
                raise ValueError('Input changed during check; no patch applied')
            if any((root/name).exists() for name in proposed if name not in originals):
                raise ValueError('New path appeared during check; no patch applied')
            run_git(['apply', '--whitespace=error', str(patch_path)], root)
            report['repository_modified'] = True
            for name, expected_sha in report['changed_file_sha256'].items():
                if sha((root/name).read_bytes()) != expected_sha:
                    raise ValueError('Post-apply byte mismatch: ' + name)
            report['applied_bytes_verified'] = True
        report['ok'] = True
    except Exception as error:
        report.update(ok=False, error=dict(type=type(error).__name__, message=str(error),
            detail=error.stderr if isinstance(error, subprocess.CalledProcessError) else None))
    args.report.parent.mkdir(parents=True, exist_ok=True)
    # Never replace a previous acceptance or status report.
    with args.report.open('x', encoding='utf-8') as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({key: report.get(key) for key in ('ok', 'repository_modified', 'source_file_count',
        'source_set_sha256', 'patch_sha256', 'error')}, ensure_ascii=False))
    return 0 if report['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
