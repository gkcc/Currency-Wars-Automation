# PR30 两项消费者修正：完整离线补丁交付

**唯一父：`51798ecf7a62d8f778a799c130fc111fc2f836a5`。** 本包不是旧 PR29 导航草案，也不是已发布 PR。它仅修 PR29-R1、PR30-R1，不重做视觉校准，不合入 PR24。

已通过 GitHub 连接实际读取 PR30 元数据、STARTUP_GUIDE_ACTIONABILITY.md、相关消费者/夹具，以及冻结证据 `487f173f8eca1d7d472cfea9c7130a8d136baec9` 的两份独立审查与 Windows 验收。本轮 GitHub 连接器无 create/write 操作，运行容器无法解析 GitHub 域名；没有声称本地 fetch 成功或远端发布。按用户授权的替代交付方式，ROOT 只需严格应用现成代码、运行固定检查和冻结发布，不需要补实现。

## 包含的实际代码

`PR30_retry_obligations.patch` 是普通 UTF-8 unified patch，包含以下5个仓库路径：

1. `tools/currency_wars_manual_steps.py`：原 checkpoint lock 内按原恢复义务检查所有已接受尝试；第一次无 continuation 的失败也去重，真正新 inspect 才可再审。
2. `tools/currency_wars_runner.py`：沿 refused successor 的 prior-unknown 归档链核原未决，普通 native plan 不能因最新零输入拒绝而获得点击资格。
3. `tools/test_currency_wars_retry_obligations.py`：两条完整既有 Worker/Entry/ManualPhase 消费者回归，调用原夹具，无源码字符串/AST扫描测试。
4. `tools/replay_currency_wars_retry_obligations.py`：精确选择新2项＋原受影响post-persistence失败恢复1项，共3项；输出完整来源/素材/加载闭包/原始失败。
5. `handoff/2026-10-08/RETRY_OBLIGATION_FIX.md`：完整行为、当前接口、边界及发布说明。

无新生产模块、operation、proof字段、第三方依赖、GUI/Rust/manifest/素材/控制器。原页面/帧/owner/epoch/deadline/前台/ROI/收据及实际后继读取保持原消费者。

### PR29-R1

旧 jobID 仍幂等读结果。新 jobID、改findings/deadline都不构成新来源。按原 step/input/run/match/stage 检查 mailbox，失败报告必须已terminal refused、零输入、完整水位/交付、无未知且与持久归档一致。重审必须来自失败后同manual binding的真实已完成 inspect；request/capture/frame 均新，PNG内容允许相同。无当前continuation文件不能绕过此门槛。旧pending、原收据、两次自动读预算和归因不变。

### PR30-R1

最新attempt只是指针，不再代表所有未决已经解除。零输入拒绝时沿 prior 链读取并认证原归档/源PNG/同owner原收据；遗漏、循环、越界或交付未知拒绝。原pending仍要求完整原交付和当前明确主管proof。新显式主管动作继续指向原pending；旧归档字节保持。实际只读到“创业指南”标题仍不完成任务阶段。

## 严格应用：只在ROOT隔离目录

有Git的隔离checkout，HEAD必须正好为上述PR30；不可变archive无.git时，工具不伪填head，通过冻结35源码＋19素材摘要核字节。`references/PARENT_BYTES.json` 的35项source-set是原 `495f5810972d758570624ec143a7d73b406a465f870ab4f5e0db69bbe3c4bf48`。

先校验（不改输入目录）：

```powershell
$bundle = 'D:\review\pr30-retry-fix'
$repo = 'D:\review\pr30-isolated'
$evidence = 'D:\review\acceptance'
python -B -X utf8 "$bundle\strict_apply.py" --repo $repo --isolated-review-directory --check --report "$evidence\patch-check.json"
if ($LASTEXITCODE -ne 0) { throw '补丁或PR30字节校验失败，不继续' }
```

实际应用完全相同的固定补丁：

```powershell
python -B -X utf8 "$bundle\strict_apply.py" --repo $repo --isolated-review-directory --apply --report "$evidence\patch-applied.json"
if ($LASTEXITCODE -ne 0) { throw '应用失败，保留报告，不部署' }
```

检查器先在临时目录复制两份完整原源码，通过 `git apply --check` 和真正的 `git apply`，逐字节对照固定替换计划并compile；仅 `--apply` 才写指定隔离目录。它不执行项目源码、不改Git index或分支，不下载、不清生产缓存、不改READY。检查/应用报告必须用不存在的新文件名，避免覆盖原验收。

`patch-applied.json` 给出：补丁SHA、唯一父、实际所有37项源码SHA和source-set、19项素材SHA、5个变更文件的最终SHA。完整runner新摘要必须从真实应用后的全文件计算；本环境没有完整父文件，不伪造这个值。此来源报告可直接交独立reviewer。

也可审阅并手动使用普通 `git apply --check`/`git apply`，但仍须先核唯一父与PARENT_BYTES，不使用三方合并或补上下文。

## Windows 固定消费者检查

```powershell
Push-Location $repo
try {
  python -B -X utf8 tools/replay_currency_wars_retry_obligations.py --output "$evidence\retry-obligations-windows.json"
  if ($LASTEXITCODE -ne 0) { throw '聚焦消费者检查未通过，不冻结为已验候选' }
} finally { Pop-Location }
```

预期：3个明确方法、0 failure/error/skip、37源码/24 production/19既有素材，测前后无差，loaded closure missing=[]。若ROOT在archive中额外放入GAME_KNOWLEDGE，素材数可能多1，按实际map审查；不需要私有57素材。此入口不会运行原PR29的全8项、原PR30的全9项、经济或GUI。

两条新回归严格复现：
- 首次恢复金币unknown、无continuation、旧q不变；同proof新ID零捕获；新inspect可以同PNG但新capture/frame；旧灰球预算/历史及失败报告不变。
- 原导航pending；新主管动作发布前失去前台拒绝；新inspect普通native plan零新发布；再新inspect明确主管proof可继续，旧unknown与拒绝归档均不变。

原第三项保留已有“continuation写盘后通知失败”的合法新inspect重试，防止此次前置去重把它永久封死。

## 本轮实际验证级别

- 实际执行了所交付两个修改函数的6项本地单元检查：全部通过。原版导航函数对refused指针返回无义务，新函数对同链拒绝native并允许新主管。包含缺源/循环/污染、恢复原来源复用、新ID但无inspect、同SHA新捕获、旧失败状态不完整等。
- 实际用git对精确取回的修改hunk及声明周边文本执行apply/check，并逐字节核新代码、compile所有Python；临时目录已删除。
- **未在本环境取得完整PR30仓库/运行完整3项Worker消费者。** 本地单元的runner/Entry为显式facade，不能当成完整消费者或Windows通过。完整消费者测试代码已经交付，结果由ROOT在真实完整冻结源码上执行产生。
- 无原生新PNG/新OCR、物理游戏输入、实际导航、部署或速度结论。父PR29/PR30的Windows结果仅引用ROOT已报告事实，不重复计为本次验收。

## 冻结与一次部署链

ROOT在以PR30为HEAD的独立分支中，只提交上述5个路径。提交后核 `git rev-list --parents -n 1 HEAD` 只有PR30这一个父，再发布候选。本包没有虚构远端head，补丁SHA是当前不变交付身份。

当前生产仍PR28；最终部署时采用PR30全栈加本补丁，不能只拷两个文件。沿原绑定与检查流程审24源码+64资源/provider、GUI编译输入、READY/check-launch。manifest和GUI输入本补丁未改，是否可复用以ROOT原审查为准。正常原生start/business_resume，同局当前阶段继续，不重领已领球、不把历史unknown改成功。

## 当前接口不变

奖励恢复：原17字段 `reward_recovery`，原 `manual-step recover_reward`。同jobID读取；一次refused后必须原 `manual-step inspect`，核新完整请求的capture/frame再填新proof。返回unknown/缺源时保持原未决，不自动循环重审。

导航：首个原生动作继续原 `decide` 或受检 `reviewed_plan`。存在原已发布unknown时，普通无source动作会在新捕获/输入之前拒绝；只接受同ManualPhase的真正当前17字段主管 `reviewed_plan`。发布前失前台而零输入后，主管要求仍在。未知交付先查原ID，不能换job绕过。源链损坏则只读退出/回ROOT，不删归档、不改预算。

普通导航和主管proof完整样例继续引用父PR30的 `STARTUP_GUIDE_ACTIONABILITY.md`；本次不改其字段和实际后继验收。任务阶段、领空、经济预算、出战审批绝不由只见标题自动完成。
