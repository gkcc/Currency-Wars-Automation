"""Local unit execution of the delivered guard fragments, NOT the full Worker.

Only the two changed functions run. Existing runner/Entry APIs are explicit
facades; live ownership, vision, transport and full consumer tests are outside
this local check. The real fixture consumer tests are delivered separately.
"""
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import tempfile
from types import SimpleNamespace, MethodType
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('delivered_recovery',ROOT/'fragments/recovery_helper.py')
recovery=importlib.util.module_from_spec(spec)
spec.loader.exec_module(recovery)
recovery.Path=Path
recovery.datetime=datetime
recovery.SCHEMA='manual-worker-step/v1'

def read(path): return json.loads(Path(path).read_text())
def save(path,value):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(value,sort_keys=True),encoding='utf-8')
def sha(data): return hashlib.sha256(data).hexdigest()
def optional(path): return read(path) if Path(path).exists() else None

def nav_class(filename):
    ns=dict(Path=Path,re=re,hashlib=hashlib,optional=optional,
        await_existing_receipt=lambda run,c,rid,wait: c.receipts[rid],
        manual_receipt_state=lambda receipt: receipt['state'])
    exec(compile('class Worker:\n'+(ROOT/filename).read_text(),filename,'exec'),ns)
    return ns['Worker']

NEW=nav_class('fragments/navigation_check.new.py')
OLD=nav_class('fragments/navigation_check.old.py')

class LogicChecks(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='cw-local-obligation-unit-')
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name); self.run=self.root/'run'; self.records=self.root/'records'
        self.run.mkdir(); self.records.mkdir(); (self.run/'manual-steps').mkdir()
        self.owner=dict(run_id='run')
        self.binding=dict(run_id='run',match_id='match',stage='1-1',old_epoch='epoch',manual_id='manual')
        self.pending=dict(step_id='a'*32,request_id='input',match_id='match',before=dict(stage='1-1'))
        self.old=dict(request_id='old-q',capture_request_id='old-c',frame_id='old-f',snapshot_id='same-png',
                      reward_step_id='a'*32,input_request_id='input',match_id='match',page='preparation',stage='1-1')
        self.new=dict(self.old,request_id='new-q',capture_request_id='new-c',frame_id='new-f')
        self.bound=[]; self.unknown=[]
        r=SimpleNamespace(entry=SimpleNamespace(read_json=read),redact=copy.deepcopy)
        recovery._runner=lambda:r
        recovery._path=lambda run,sid:Path(run)/'manual-steps'/(sid+'.json')
        recovery.unknown_receipts=lambda run,c:self.unknown
        recovery._bound_reward_frame=lambda *args,**kwargs:self.bound.append((args,kwargs))
        self.failed=self.job('b'*32,'recover_reward','refused',self.old,
                             '2026-10-08T10:00:00+00:00','2026-10-08T10:00:01+00:00')
    def job(self,sid,operation,status,evidence,started,finished):
        result=dict(receipt_watermark_verified=True,receipt_delivery_verified=True,input_receipt_ids=[],
             receipt_states=[dict(state='zero_input',unknown_input=False)],evidence_errors=[],prior_unknown_receipt_ids=[])
        if operation=='inspect':
            result.update({k:evidence[k] for k in ('snapshot_id','capture_request_id','frame_id','page','stage')})
            result['decision_request_id']=evidence['request_id']
        value=dict(schema=recovery.SCHEMA,run_id='run',step_id=sid,binding=copy.deepcopy(self.binding),
             status=status,payload=dict(operation=operation,reply={'reward_recovery':copy.deepcopy(evidence)}),
             result=result,started_at=started,finished_at=finished)
        self.write_job(value)
        return value
    def write_job(self,value):
        save(self.run/'manual-steps'/(value['step_id']+'.json'),value)
        save(self.records/('manual-step-'+value['step_id']+'.json'),value)
    def check(self,evidence):
        return recovery._check_recovery_retry(self.run,self.owner,None,self.records,self.pending,evidence,
            dict(observation=evidence,original_png='declared-current-path'),self.binding,
            list((self.run/'manual-steps').glob('*.json')))
    def inspect(self):
        return self.job('c'*32,'inspect','returned',self.new,
                  '2026-10-08T10:00:02+00:00','2026-10-08T10:00:03+00:00')
    def test_recovery_old_source_before_continuation_is_refused(self):
        for change in ({},{'findings':'new prose'},{'deadline_at':'later'}):
            with self.subTest(change=change),self.assertRaises(ValueError): self.check(dict(self.old,**change))
        self.assertEqual(self.bound,[])
        self.assertFalse(list(self.records.glob('reward-continuation*')))
    def test_recovery_new_ids_require_actual_retained_inspect_same_hash_allowed(self):
        with self.assertRaises(ValueError):self.check(self.new)
        self.inspect(); self.check(self.new)
        self.assertEqual(len(self.bound),1)
        self.assertTrue(self.bound[0][1]['read_only'])
        self.assertEqual(self.old['snapshot_id'],self.new['snapshot_id'])
    def test_recovery_prior_report_and_inspect_integrity_fail_closed(self):
        inspect=self.inspect()
        for change in ('returned','running','unknown','archive_missing','no_watermark','early_inspect'):
            with self.subTest(change=change):
                self.write_job(self.failed); self.write_job(inspect)
                value=copy.deepcopy(self.failed)
                if change in ('returned','running'):value['status']=change;self.write_job(value)
                if change=='unknown':self.unknown=['original-unknown']
                if change=='archive_missing':(self.records/('manual-step-'+value['step_id']+'.json')).unlink()
                if change=='no_watermark':value['result']['receipt_watermark_verified']=False;self.write_job(value)
                if change=='early_inspect':
                    v=copy.deepcopy(inspect);v['started_at']='2026-10-08T09:59:59+00:00';self.write_job(v)
                with self.assertRaises((ValueError,FileNotFoundError)):self.check(self.new)
                self.unknown=[]
        self.assertEqual(self.bound,[])
    def nav(self, cls):
        worker=cls(); worker.run=self.run;worker.records=self.records
        worker.owner=self.owner;worker.active_match_id='match';worker.c=SimpleNamespace(receipts={})
        worker.startup_navigation_delivery=lambda item: worker.c.receipts[item['input_request_id']]
        original=self.nav_record(worker,'d'*32,'pending',True,None)
        refusal=self.nav_record(worker,'e'*32,'refused',False,original['request_id'])
        save(self.run/'startup-navigation.json',refusal)
        q=dict(request_id='f'*32,observation=dict(capture_request_id='new-cap',frame_id='new-frame'))
        return worker,original,refusal,q
    def nav_record(self, worker, rid, status, published, prior):
        payload=('unit-frame-'+rid).encode(); png=self.records/(rid+'.png');png.write_bytes(payload)
        cap='cap-'+rid;frame_id='frame-'+rid
        source=dict(snapshot_id=sha(payload),capture_request_id=cap,frame_id=frame_id)
        worker.c.receipts[cap]=dict(id=cap,state=dict(state='zero_input',unknown_input=False),result=dict(ok=True,
            observation=dict(frame_protocol=1,request_id=cap,frame_id=frame_id,snapshot_sha256=sha(payload))))
        input_id='input-'+rid if published else None
        if published:worker.c.receipts[input_id]=dict(id=input_id,state=dict(state='completed',unknown_input=False))
        record=dict(schema='startup-guide-navigation/v1',run_id='run',match_id='match',request_id=rid,
            status=status,outcome='unknown' if status=='pending' else 'zero_input',publication_attempted=published,
            input_request_id=input_id,source_frame=source,source_png=str(png),
            prior_unknown_navigation_request_id=prior,record_file=str(self.records/('guide-navigation-'+rid+'.json')))
        save(record['record_file'],record)
        return record
    def test_native_plan_parent_accepts_but_candidate_refuses_prior_pending_chain(self):
        old,_,_,q=self.nav(OLD)
        self.assertIsNone(old.check_startup_navigation_attempt(dict(target_evidence={}),q))
        new,original,refusal,q=self.nav(NEW)
        raw=Path(original['record_file']).read_bytes()
        with self.assertRaises(ValueError):new.check_startup_navigation_attempt(dict(target_evidence={}),q)
        self.assertEqual(Path(original['record_file']).read_bytes(),raw)
    def test_explicit_new_supervisor_keeps_original_link_and_same_png_policy(self):
        worker,original,refusal,q=self.nav(NEW)
        action=dict(target_evidence=dict(source='supervising_agent'))
        self.assertEqual(worker.check_startup_navigation_attempt(action,q),original['request_id'])
        for record in (original,refusal):
            for key in ('capture_request_id','frame_id'):
                with self.subTest(record=record['request_id'],key=key):
                    bad=copy.deepcopy(q);bad['observation'][key]=record['source_frame'][key]
                    with self.assertRaises(ValueError):worker.check_startup_navigation_attempt(action,bad)
    def test_navigation_chain_missing_cycle_and_source_corruption_refuse(self):
        action=dict(target_evidence=dict(source='supervising_agent'))
        for change in ('missing','cycle','source','owner'):
            with self.subTest(change=change):
                worker,original,refusal,q=self.nav(NEW)
                if change=='missing':Path(original['record_file']).unlink()
                if change=='cycle':
                    refusal['prior_unknown_navigation_request_id']=refusal['request_id']
                    save(refusal['record_file'],refusal);save(self.run/'startup-navigation.json',refusal)
                if change=='source':Path(original['source_png']).write_bytes(b'changed')
                if change=='owner':
                    original['run_id']='other';save(original['record_file'],original)
                with self.assertRaises(ValueError):worker.check_startup_navigation_attempt(action,q)

if __name__=='__main__':unittest.main(verbosity=2)
