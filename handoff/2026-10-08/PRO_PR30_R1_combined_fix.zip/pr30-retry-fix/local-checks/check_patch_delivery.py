"""Check fixed patch mechanics on source-hunk fixtures, not full parent checkout."""
from pathlib import Path
import hashlib,json,subprocess,tempfile
P=Path(__file__).resolve().parents[1]
rules=json.loads((P/'replacements.json').read_text())
manual='''from pathlib import Path
from datetime import datetime
'''+rules[0]['old']+'''    This is only a hunk fixture, not the original implementation.
    """
    return None


def submit():
    if True:
        if True:
            if True:
'''+rules[1]['old']+'''                pass
'''
runner='''import re
from pathlib import Path
class Worker:
'''+rules[2]['old']
report={'scope':'git apply mechanics on exact retrieved hunks with declared surrounding source, not full PR30',
        'full_parent_checkout_applied':False,'full_consumer_tests_run':False}
with tempfile.TemporaryDirectory(prefix='cw-patch-delivery-') as tmp:
 root=Path(tmp)
 orig={'tools/currency_wars_manual_steps.py':manual,'tools/currency_wars_runner.py':runner}
 for name,text in orig.items():
  path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text)
 for args in (['--check'],[]):
  process=subprocess.run(['git','apply',*args,'--whitespace=error',str(P/'PR30_retry_obligations.patch')],cwd=root,capture_output=True,text=True)
  if process.returncode:raise RuntimeError(process.stderr)
 expected=dict(orig)
 for rule in rules:
  assert expected[rule['path']].count(rule['old'])==1
  expected[rule['path']]=expected[rule['path']].replace(rule['old'],rule['new'],1)
 for path in (P/'files').rglob('*'):
  if path.is_file():expected[path.relative_to(P/'files').as_posix()]=path.read_text()
 for name,text in expected.items():
  assert (root/name).read_bytes()==text.encode(),name
  if name.endswith('.py'):compile(text,name,'exec')
 report.update(ok=True,git_apply_check=True,git_apply=True,exact_transformation_matches=True,
               touched_files=len(expected),python_compiles=True)
report['owned_temporary_directory_removed']=not root.exists()
(P/'local-checks/patch-delivery.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
