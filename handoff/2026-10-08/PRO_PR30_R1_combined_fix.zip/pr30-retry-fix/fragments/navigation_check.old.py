    def check_startup_navigation_attempt(self, action, request):
        path = self.records / ('guide-navigation-' + request['request_id'] + '.json')
        if path.exists():
            raise ValueError('本次创业指南请求已有原尝试；读取原记录，不重发')
        previous = optional(self.run / 'startup-navigation.json') or {}
        if (previous.get('match_id') == self.active_match_id and previous.get('status') == 'pending'
                and previous.get('publication_attempted') is True):
            if (previous.get('run_id') != self.owner['run_id'] or optional(self.records /
                    ('guide-navigation-' + previous['request_id'] + '.json')) != previous):
                raise ValueError('原导航记录归属/归档不符；不绕过pending')
            self.startup_navigation_delivery(previous)
            # A later explicitly reviewed current target is a new manual
            # intent. The prior navigation's historical unknown is retained.
            if (action.get('target_evidence', {}).get('source') != 'supervising_agent'
                    or any(request.get('observation', {}).get(key) == previous.get('source_frame', {}).get(key)
                           for key in ('capture_request_id', 'frame_id'))):
                raise ValueError('原导航后继未知；只读/当前ManualPhase复核，不能自动再点原图标')
            return previous['request_id']
        return None
