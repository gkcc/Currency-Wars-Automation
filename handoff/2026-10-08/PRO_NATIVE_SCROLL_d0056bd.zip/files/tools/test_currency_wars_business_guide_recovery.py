"""Current-lease Guide recovery through actual Worker/decide/Entry consumers.

The Worker constructor, business continuation, publish, tick, CLI validation,
GuardedSubmission, Entry ledger and original business-resume review all run.
Process/window probes and the publisher are inert declarations. Native Guide
crops and offline OCR come from the accompanying native-scroll helper; their
outer canvas and the preparation successor are declared protocol fixtures.
No controller, Windows startup/UAC, native input, or old manual-flow fixture
runs. The startup's existing final explicit_resume call is exercised directly.
"""
from __future__ import annotations

import contextlib
import copy
from datetime import datetime, timedelta, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import uuid

from PIL import Image

import currency_wars_artifacts as artifacts
import currency_wars_broker_entry as entry
import currency_wars_perception as perception
import currency_wars_runner as runner
from test_currency_wars_native_scroll import native_canvas


ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = []


def preparation_canvas():
    """Declared successor HUD, never a retained real-game postcondition."""
    image = Image.new('RGB', (1920, 1080), (31, 36, 40))
    output = io.BytesIO()
    image.save(output, format='PNG')
    payload = output.getvalue()
    value = dict(page='preparation', fields=dict(stage='1-1', coins=6, level=3, xp='0/4', deployed='0/3'),
        rows=[dict(text='备战阶段', confidence=.99, box=[400, 24, 520, 65]),
              dict(text='1-1', confidence=.99, box=[530, 24, 610, 65])],
        semantic={}, elapsed_ms=0., snapshot_id=hashlib.sha256(payload).hexdigest(),
        fingerprint=perception.fingerprint(image),
        read_contract=dict(version=runner.READ_CONTRACT_VERSION, effective_scope='full', unread=[]))
    image.close()
    return dict(payload=payload, observation=value)


def changed_canvas(frame, *, cover=False, text=False):
    value = copy.deepcopy(frame)
    if cover:
        with Image.open(io.BytesIO(frame['payload'])) as source:
            image = source.convert('RGB')
        image.paste((45, 45, 45), (300, 190, 600, 266))
        output = io.BytesIO()
        image.save(output, format='PNG')
        value['payload'] = output.getvalue()
        value['observation']['snapshot_id'] = hashlib.sha256(value['payload']).hexdigest()
        value['observation']['fingerprint'] = perception.fingerprint(image)
        image.close()
    if text:
        for row in value['observation']['rows']:
            if perception.clean(row.get('text', '')) == '创业指南':
                row['text'] = '创业指引'
    return value


@contextlib.contextmanager
def recovery_fixture(*, current_change=None, successor='preparation'):
    with tempfile.TemporaryDirectory(prefix='cw-business-guide-recovery-') as temporary:
        project = Path(temporary)
        (project / 'debug').mkdir()
        (project / 'docs').mkdir()
        chat = 'declared-business-guide-recovery'
        frames = dict(source=native_canvas('guard-source'), current=native_canvas('scroll-one-before'),
                      preparation=preparation_canvas())
        if current_change:
            frames['current'] = changed_canvas(frames['current'], **{current_change: True})
        by_digest = {frame['observation']['snapshot_id']: frame for frame in frames.values()}

        class Control:
            def __init__(self):
                self.generation, self.frame = 1, 'source'
                self.published, self.inputs, self.resume_ids = [], [], []
                self.mutex, self.lock_depth = threading.RLock(), 0
                self.before_input, self.unknown_delivery = None, False
                self.before_publication_record = None
                self.before_status_return = None

            def write_json(self, path, value):
                Path(path).write_text(json.dumps(value), encoding='utf-8')
                request = value.get('request') or {} if isinstance(value, dict) else {}
                if (Path(path).parent.name == 'request-ledger' and value.get('result') is None
                        and any(a.get('type') not in ('observe', 'wait') for a in request.get('actions', []))
                        and self.before_input is not None):
                    callback, self.before_input = self.before_input, None
                    callback()
                if (Path(path).name == 'business-guide-recovery.json' and value.get('publication_attempted') is True
                        and self.before_publication_record is not None):
                    callback, self.before_publication_record = self.before_publication_record, None
                    callback()

            def process_probe(self, pid, expected=None):
                creation = {os.getpid(): str(1000 + self.generation),
                            202 + self.generation: str(2000 + self.generation), 303: '3003'}.get(pid)
                if creation is None:
                    return dict(pid=pid, state='absent')
                if expected is not None and str(expected) != creation:
                    return dict(pid=pid, state='reused', creation_id=creation)
                return dict(pid=pid, state='running', creation_id=creation)

            def win(self):
                return 333, 303, (0, 0, 1920, 1080)

            def integrity(self, unused):
                return dict(integrity_rid=8192)

            def latch_pause(self, reason):
                value = dict(pause_id=uuid.uuid4().hex, reason=reason)
                self.write_json(Path(self.ROOT) / 'manual-pause.json', value)
                return value

            def pause(self, reason):
                self.latch_pause(reason)
                return dict(ok=True, **self.status())

            def assert_owner(self, value_chat, value_token):
                if (value_chat, value_token) != (self.OWNER['chat_id'], self.OWNER['run_token']):
                    raise ValueError('declared transport owner mismatch')

            def status(self):
                run = Path(self.ROOT)
                paused = runner.optional(run / 'manual-pause.json')
                value = dict(ready=True, paused=bool(paused), input_halted=(run / 'input-halted.json').exists(),
                    game_foreground=True, acknowledged=True, broker_pid=202 + self.generation,
                    broker_creation_time=str(2000 + self.generation), broker_state=dict(state='running'),
                    pause_id=paused['pause_id'] if paused else None, reason=paused['reason'] if paused else None)
                if self.before_status_return is not None:
                    callback, self.before_status_return = self.before_status_return, None
                    callback()
                return value  # The injected takeover may make this status stale.

            @contextlib.contextmanager
            def submission_lock(self):
                with self.mutex:
                    self.lock_depth += 1
                    try:
                        yield
                    finally:
                        self.lock_depth -= 1

            def validate_actions(self, actions):
                return [dict(type=action['type'], args=[float(value) for value in action['args']])
                        for action in actions]

            def publish_request(self, request):
                if self.lock_depth <= 0:
                    raise AssertionError('actual Entry lease was not retained at inert publication')
                self.assert_owner(request['chat_id'], request['run_token'])
                run = Path(self.ROOT)
                self.published.append(copy.deepcopy(request))
                if request['kind'] == 'resume':
                    if request.get('expected_pause_id') != self.status()['pause_id']:
                        raise ValueError('declared original pause changed')
                    self.resume_ids.append(request['id'])
                    (run / 'manual-pause.json').unlink(missing_ok=True)
                    result = dict(id=request['id'], ok=True, resumed=True, completed=[])
                else:
                    actions = copy.deepcopy(request['actions'])
                    physical = [a for a in actions if a['type'] not in ('observe', 'wait')]
                    if physical:
                        if physical != [dict(type='key', args=[27.])] or self.status()['paused']:
                            raise AssertionError('unexpected or paused action at inert publisher')
                        self.inputs.extend(physical)
                        if successor == 'preparation':
                            self.frame = 'preparation'
                    result = dict(id=request['id'], ok=True, completed=actions,
                        input_attempted=bool(physical), attempted_actions=copy.deepcopy(physical))
                    if physical and self.unknown_delivery:
                        result.update(ok=False, completed=[], error='declared unknown Escape delivery')
                frame = frames[self.frame]
                frame_id = uuid.uuid4().hex
                directory = run / 'frames' / (hashlib.sha256(request['id'].encode()).hexdigest() + '-' + frame_id)
                directory.mkdir(parents=True)
                for name in ('preview.png', 'original.png'):
                    (directory / name).write_bytes(frame['payload'])
                result.update(offline_fixture_receipt=True, observation=dict(frame_protocol=1,
                    request_id=request['id'], frame_id=frame_id, captured_at=runner.now(),
                    snapshot=str(directory / 'preview.png'), original=str(directory / 'original.png'),
                    snapshot_sha256=frame['observation']['snapshot_id'], original_sha256=frame['observation']['snapshot_id'],
                    snapshot_size=[1920, 1080], original_size=[1920, 1080]))
                self.write_json(run / 'result.json', result)

        control = Control()

        def read(path, **unused):
            digest = hashlib.sha256(Path(path).read_bytes()).hexdigest()
            return copy.deepcopy(by_digest[digest]['observation'])

        reader = SimpleNamespace(read=read)

        def make_worker(name, continuation=None):
            run = project / name
            run.mkdir()
            marker = dict(schema=1, tool=artifacts.TOOL, path=str(run), root=str(project),
                run_id=uuid.uuid4().hex, purpose='currency-wars-runner-recovery-fixture', pid=os.getpid(),
                process_identity='windows:' + str(1000 + control.generation), children_incomplete=False,
                protected_children=[], session_hint=dict(source='environment-declared', id=chat))
            control.write_json(run / artifacts.MARKER, marker)
            args = SimpleNamespace(chat_id=chat, launch_id=uuid.uuid4().hex, max_seconds=600,
                max_matches=1, profile=False, business_resume_json=continuation)
            worker = runner.Worker(args, run, control, marker)
            control.write_json(run / 'broker-process.json', dict(chat_id=chat, run_token=worker.token,
                pid=202 + control.generation, creation_id=str(2000 + control.generation)))
            control.write_json(run / 'broker-ready.json', dict(ready=True))
            worker.publish()
            return worker

        with patch.object(runner, 'PROJECT', project), patch.object(runner, 'CURRENT', project / 'docs' / 'CURRENT_RUNNER.json'), \
                patch.object(runner, 'Perception', return_value=reader), patch.object(entry, 'backend', return_value=control):
            old = make_worker('old-runtime')
            # This declared historical pending record is never executed. The
            # original archive must survive actual business continuation.
            old_id = uuid.uuid4().hex
            old_receipt = dict(id=old_id, request=dict(id=old_id, kind='actions', chat_id=chat,
                run_token=old.token, handoff=False, actions=[dict(type='key', args=[70.])]), result=None)
            old_archive = runner.archive_business_receipt(old.records, old.owner, old_receipt, control)
            old_bytes = old_archive.read_bytes()
            old.publish(control_mode='stopped')
            previous_state = copy.deepcopy(old.state)
            shutil.rmtree(old.run)  # Only this declared temporary fixture.
            control.generation = 2
            contract = runner.prepare_business_start(previous_state, control, chat)
            worker = make_worker('current-runtime', contract)
            initial = runner.explicit_resume(worker.run, worker.owner, control, uuid.uuid4().hex,
                expected_manual_id=worker.initial_manual_id, expected_broker_pause_id=worker.initial_broker_pause_id)
            if not initial.get('resumed'):
                raise AssertionError('declared startup final handoff failed')
            worker.publish(control_mode='auto')
            control.published.clear()
            yield worker, control, dict(old_archive=old_archive, old_bytes=old_bytes,
                old_request_id=old_id, original_epoch=worker.epoch(), match_id=old.active_match_id,
                frames=frames, by_digest=by_digest)


def escape_reply(worker):
    request = worker.state['decision_request']
    return dict(request_id=request['request_id'], snapshot_id=request['snapshot_id'], resume_epoch=worker.epoch(),
        actions=[dict(type='key', args=[27], expected_page='unknown', guard_texts=['创业指南'],
                      reason='当前完整指南覆盖已核，只关闭一次，随后原业务须全场鲜帧独立确认')])


def submit_decision(worker, reply):
    path = worker.records / ('declared-reply-' + uuid.uuid4().hex + '.json')
    worker.c.write_json(path, reply)
    return runner.command_cli(SimpleNamespace(command='decide', run_dir=str(worker.run),
        chat_id=worker.owner['chat_id'], run_token=worker.owner['run_token'], reply_file=str(path)))


def business_reply(worker):
    request = worker.state['decision_request']
    record = dict(proof=dict(source='observed_screen', snapshot_id=request['snapshot_id'],
        capture_request_id=request['observation']['capture_request_id'], evidence_file=request['evidence_file'],
        resume_epoch=worker.epoch()), value=dict(reviewer='supervising_agent', match_id=worker.active_match_id,
        previous_run_id=worker.business_previous_run, previous_chat_id=worker.business_previous_chat,
        current_chat_id=worker.owner['chat_id'], disposition='same_match',
        unresolved_requests=sorted(item['origin_run_id'] + ':' + item['request_id'] for item in worker.business_unknown),
        prior_outcomes_remain_unknown=True, remaining_policy='fresh_reviews_and_current_balance',
        continuity_basis='声明协议测试：原业务身份连续，当前独立全场鲜帧逐项核对，旧未知仍保持未知。',
        current_state=dict(page='preparation', stage='1-1', coins=6, level=3, xp=[0, 4],
            deployed='0/3', roster=['declared-current-role'], selected_strategy='declared-current-strategy')))
    return dict(request_id=request['request_id'], snapshot_id=request['snapshot_id'], resume_epoch=worker.epoch(),
        context_update=dict(business_resume=record),
        actions=[dict(type='finish_preparation_review', reason='只提交当前全场业务复核，准备阶段另由当前事实验收')])


class BusinessGuideRecoveryTests(unittest.TestCase):
    def request(self, worker):
        observed = worker.observe()
        worker.tick(observed)
        self.assertTrue(runner.business_guide_recovery_request(worker.state.get('decision_request')))
        self.assertEqual(worker.state['decision_request']['observation']['page'], 'unknown')
        self.assertEqual(worker.state['decision_request']['allowed_action_types'], ['key'])
        self.assertIsNone(worker.last_preparation_stage)
        self.assertIsNone(worker.state['preparation_stage'])
        return escape_reply(worker)

    def test_current_guide_escape_then_original_fresh_business_resume(self):
        with recovery_fixture() as (worker, control, evidence):
            self.assertTrue(worker.business_needs_review)
            self.assertEqual(worker.active_match_id, evidence['match_id'])
            reply = self.request(worker)
            before_business = copy.deepcopy(worker.business_unknown)
            control.frame = 'current'
            self.assertTrue(submit_decision(worker, reply)['ok'])
            self.assertTrue(worker.tick_decision())
            self.assertEqual(control.inputs, [dict(type='key', args=[27.])])
            recovery = entry.read_json(worker.run / 'business-guide-recovery.json')
            self.assertEqual((recovery['status'], recovery['outcome']), ('verified', 'guide_closed'))
            self.assertTrue(worker.business_needs_review)
            self.assertFalse(recovery['business_resume_approved'])
            self.assertFalse(recovery['automatic_phase_completion'])
            self.assertEqual(worker.epoch(), evidence['original_epoch'])
            self.assertEqual(worker.last_preparation_stage, '1-1')
            # The normal run loop makes a NEW observe after the action's own
            # returned frame, before issuing the original business request.
            worker.tick(worker.observe())
            request = copy.deepcopy(worker.state['decision_request'])
            self.assertEqual(request['kind'], 'business_resume')
            self.assertNotEqual(request['observation']['capture_request_id'], recovery['input_request_id'])
            self.assertIn(recovery['input_request_id'], request['business_receipt_watermark'])
            review = business_reply(worker)
            self.assertTrue(submit_decision(worker, review)['ok'])
            self.assertTrue(worker.tick_decision())
            self.assertFalse(worker.business_needs_review)
            self.assertFalse(worker.state['business']['resume_review_required'])
            self.assertEqual(worker.business_unknown, before_business)
            self.assertEqual(evidence['old_archive'].read_bytes(), evidence['old_bytes'])
            self.assertEqual(worker.active_match_id, evidence['match_id'])
            self.assertEqual(worker.epoch(), evidence['original_epoch'])
            self.assertEqual(worker.preparation_reviews, {})
            self.assertEqual(len(control.inputs), 1)
            EVIDENCE.append(dict(case='business_guide_recovery_then_fresh_resume', passed=True,
                constructor_and_publish='production', startup_process_launch_executed=False,
                original_input_id=recovery['input_request_id'], declared_inputs=1,
                native_page_before='unknown', stage_before=None, stage_after='1-1',
                recovery_approves_business=False, original_business_resume_consumed=True,
                epoch_changed_by_escape=False, historical_unknown_unchanged=True))

    def test_invalid_recovery_payloads_and_fresh_frame_changes_refuse_input(self):
        cases = ('key70', 'two_keys', 'context', 'missing_guard', 'cover', 'text', 'source', 'epoch')
        for case in cases:
            with self.subTest(case=case), recovery_fixture(current_change=case if case in ('cover', 'text') else None) as (worker, control, unused):
                reply = self.request(worker)
                control.frame = 'current'
                if case == 'key70':
                    reply['actions'][0]['args'] = [70]
                elif case == 'two_keys':
                    reply['actions'].append(copy.deepcopy(reply['actions'][0]))
                elif case == 'context':
                    reply['context_update'] = dict(business_resume={})
                elif case == 'missing_guard':
                    reply['actions'][0]['guard_texts'] = []
                if case in ('key70', 'two_keys', 'context', 'missing_guard'):
                    with self.assertRaises(ValueError):
                        submit_decision(worker, reply)
                    self.assertFalse((worker.run / 'decision-reply.json').exists())
                    self.assertIsNone(runner.manual_state(worker.run))
                else:
                    self.assertTrue(submit_decision(worker, reply)['ok'])
                    if case == 'source':
                        Path(worker.state['decision_request']['original_png']).write_bytes(b'changed source')
                    elif case == 'epoch':
                        control.write_json(worker.run / 'runner-resume-epoch.json', dict(id='later-epoch'))
                    if case == 'epoch':
                        self.assertFalse(worker.tick_decision())
                    else:
                        with self.assertRaises((ValueError, OSError)):
                            worker.tick_decision()
                self.assertEqual(control.inputs, [])
                self.assertTrue(worker.business_needs_review)
                EVIDENCE.append(dict(case='business_recovery_refused_' + case, passed=True, declared_inputs=0))

    def test_entry_publication_rechecks_pause_deadline_and_owner(self):
        for case in ('pause', 'deadline', 'owner', 'late_takeover', 'late_status_takeover'):
            with self.subTest(case=case), recovery_fixture() as (worker, control, unused):
                reply = self.request(worker)
                control.frame = 'current'
                self.assertTrue(submit_decision(worker, reply)['ok'])

                def change():
                    if case in ('pause', 'late_takeover', 'late_status_takeover'):
                        runner.latch_manual(worker.run, 'declared newer takeover', uuid.uuid4().hex)
                        control.latch_pause('declared newer takeover')
                    elif case == 'deadline':
                        worker.state['decision_request']['deadline_at'] = (
                            datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat()
                    else:
                        control.OWNER = {**control.OWNER, 'run_token': 'declared-different-owner'}

                if case == 'late_takeover':
                    control.before_publication_record = change
                elif case == 'late_status_takeover':
                    control.before_publication_record = lambda: setattr(control, 'before_status_return', change)
                else:
                    control.before_input = change
                if case == 'deadline':
                    # The existing generic publication guard reports its
                    # deadline refusal through tick_decision's normal return.
                    self.assertFalse(worker.tick_decision())
                else:
                    with self.assertRaises((ValueError, RuntimeError)):
                        worker.tick_decision()
                self.assertEqual(control.inputs, [])
                self.assertTrue(worker.business_needs_review)
                recovery = entry.read_json(worker.run / 'business-guide-recovery.json')
                self.assertFalse(recovery['publication_attempted'])
                self.assertEqual(recovery['status'], 'refused')
                EVIDENCE.append(dict(case='business_recovery_publication_refused_' + case,
                                     passed=True, declared_inputs=0))

    def test_unknown_delivery_and_unclosed_panel_never_repeat_escape(self):
        for unknown in (False, True):
            with self.subTest(unknown_delivery=unknown), recovery_fixture(successor='same') as (worker, control, unused):
                reply = self.request(worker)
                control.frame, control.unknown_delivery = 'current', unknown
                self.assertTrue(submit_decision(worker, reply)['ok'])
                if unknown:
                    with self.assertRaisesRegex(ValueError, '交付仍未核实'):
                        worker.tick_decision()
                    worker.pause_internal('declared run-loop handling of unknown recovery delivery')
                else:
                    self.assertTrue(worker.tick_decision())
                self.assertEqual(len(control.inputs), 1)
                recovery = entry.read_json(worker.run / 'business-guide-recovery.json')
                self.assertTrue(recovery['publication_attempted'])
                self.assertEqual(recovery['status'], 'pending')
                original_bytes = (worker.records / ('business-guide-recovery-' + recovery['request_id'] + '.json')).read_bytes()
                if not unknown:
                    worker.tick(worker.observe())
                    self.assertIsNone(worker.state.get('decision_request'))
                with self.assertRaisesRegex(ValueError, '未在可接受战略回答状态'):
                    submit_decision(worker, reply)
                self.assertEqual(len(control.inputs), 1)
                self.assertEqual((worker.records / ('business-guide-recovery-' + recovery['request_id'] + '.json')).read_bytes(), original_bytes)
                self.assertTrue(worker.business_needs_review)
                with self.assertRaisesRegex(RuntimeError, '业务归属'):
                    worker.command(['key:70'], 'declared forbidden economic input')
                EVIDENCE.append(dict(case='business_recovery_no_repeat_' + ('unknown_delivery' if unknown else 'panel_remains'),
                    passed=True, declared_inputs=1, input_resent=False, business_resume_approved=False))


if __name__ == '__main__':
    unittest.main()
