"""Focused PR32 native-scroll consumers over explicitly inert transport.

The five native 1380x709 PNG crops are unedited. Their unavailable outer frame
is declared gray padding at the original coordinates, never a reconstructed
native full screenshot. OCR rows replay a separately archived, actual offline
RapidOCR read of those padded images; they are not ROOT's original OCR output.
The optional first-counter boxes replay the distinct ROOT diagnosis metadata.

Manual-scroll Worker initialization uses frame_worker/ready_fixture; its state
publisher is a declared same-stage 1-1 adapter. The two normal methods use the
actual Worker constructor and publish, with current supervisor reviews passed
through ordinary decide; their Guide opening and review facts are declared.
Image reading, transport, process/window
probes and initial manual ownership are fixtures. ManualPhase constructors,
mailbox, Worker guards, GuardedSubmission, Entry lease, immutable receipts and
postconditions run unchanged. No controller, real game input or live capture.
"""
from __future__ import annotations

import contextlib
import copy
import hashlib
import io
import json
from pathlib import Path
import threading
from types import SimpleNamespace
import unittest
import uuid

from PIL import Image, ImageDraw

import currency_wars_broker_entry as entry
import currency_wars_manual_steps as steps
import currency_wars_perception as perception
import currency_wars_runner as runner
import currency_wars_visual_guards as guards
import replay_currency_wars_preparation as preparation_fixture
import test_local_runtime_compatibility as compatibility


ROOT = Path(__file__).resolve().parents[1]
PARENT = 'd0056bdc03bc967d5138781f29518a970b7ceab9'
EVIDENCE_DIR = ROOT / 'handoff/2026-10-08/ROOT_PR32_NATIVE_SCROLL'
CROP_BOUNDS = [270, 186, 1650, 895]
LIST_BOUNDS = [772, 278, 1587, 876]
ASSET_SHA256 = {
    'diagnosis.json': 'f0d1f28cd44414c0e625a52f4dbfc649a4cccee82a8f87129c04c24b2d97d57f',
    'review.html': 'ae6038a24a1dce38e72d19e6b7619c00604450cecf38da08265a33b8f2a0729a',
    'offline-ocr-replay.json': 'ee0b7570955fac238b167c9ca54288626dbb42bc697ad3bbca5ba17441c39537',
    'guard-source.png': '3696f85f65291e31e0e9d3c001ca1c5e7d3c49b6dc11c967c27d0451e2243f91',
    'scroll-one-before.png': 'c66ac7e00c72c7d98687255ae333296adb712bc0555d7d6049fcd67d1b3ded68',
    'scroll-one-after.png': '78c217d323f8fac343913fdcb538737d04f7b4b542eef952a0273ef8008aaf64',
    'scroll-two-before.png': '724a654a3de25927fb30178fd03a0da89e5db209486ba528c11253f509b6e5a9',
    'scroll-two-after.png': '425ac2339e02d314a69a63aa4bcb89931f323cf324d02f7c94e6637a34d88061',
}
EVIDENCE = []


def native_sources():
    payloads = {name: (EVIDENCE_DIR / name).read_bytes() for name in ASSET_SHA256}
    for name, payload in payloads.items():
        if hashlib.sha256(payload).hexdigest() != ASSET_SHA256[name]:
            raise ValueError('frozen native scroll asset changed: ' + name)
    diagnosis = json.loads(payloads['diagnosis.json'].decode('utf-8-sig'))
    ocr = json.loads(payloads['offline-ocr-replay.json'].decode('utf-8'))
    if (diagnosis['candidate'] != PARENT or diagnosis['guard_failure_actual_frame_retained'] is not False
            or ocr['basis_commit'] != PARENT or ocr['native_root_ocr_output'] is not False):
        raise ValueError('native scroll provenance is not the frozen PR32 evidence')
    for name, value in diagnosis['frames'].items():
        if (value['crop_bounds'] != CROP_BOUNDS or value['resized'] is not False
                or value['pixels_edited'] is not False
                or value['crop_sha256'] != ASSET_SHA256[name + '.png']
                or ocr['frames'][name]['crop_sha256'] != value['crop_sha256']):
            raise ValueError('native crop geometry or OCR provenance changed')
    return diagnosis, ocr, payloads


def _frame(image, rows, *, page='unknown', native_name=None, declaration=None):
    output = io.BytesIO()
    image.save(output, format='PNG')
    payload = output.getvalue()
    observation = dict(page=page, rows=rows,
        fields=dict(stage='1-1' if page == 'preparation' else None,
                    coins=None, level=None, xp=None, deployed=None),
        semantic={}, elapsed_ms=0., snapshot_id=hashlib.sha256(payload).hexdigest(),
        fingerprint=perception.fingerprint(image),
        read_contract=dict(version=runner.READ_CONTRACT_VERSION, effective_scope='full', unread=[]))
    return dict(payload=payload, observation=observation, native_name=native_name,
                declaration=declaration)


def native_canvas(name='guard-source', *, mutation=None, root_counter_boxes=False):
    """Unedited crop at native coordinates; mutation means a declared negative."""
    unused, ocr, payloads = native_sources()
    with Image.open(io.BytesIO(payloads[name + '.png'])) as crop:
        if crop.format != 'PNG' or crop.size != (1380, 709):
            raise ValueError('native crop dimensions changed')
        image = Image.new('RGB', (1920, 1080), (45, 45, 45))
        image.paste(crop.convert('RGB'), CROP_BOUNDS[:2])
    rows = copy.deepcopy(ocr['frames'][name]['rows'])
    declaration = 'native crop plus declared outer padding; archived actual offline OCR'
    if root_counter_boxes:
        # These are the separately supplied original ROOT OCR bounds, not a
        # correction to the independently replayed offline OCR row set.
        boxes = {'guard-source': [1462, 326, 1510, 357],
                 'scroll-one-before': [1462, 326, 1510, 357],
                 'scroll-one-after': [1462, 297, 1510, 327]}
        if name not in boxes:
            raise ValueError('no ROOT counter-box metadata for this replay variant')
        [row for row in rows if row['text'] == '0/2'][0]['box'] = boxes[name]
        declaration += '; 0/2 box separately sourced from ROOT diagnosis'
    if mutation:
        draw = ImageDraw.Draw(image)
        target = next((row for row in rows if row['text'] == '0/2'), None)
        if mutation == 'cover':
            x, y, right, bottom = target['box']
            draw.rectangle([x, y, right-1, bottom-1], fill=(45, 45, 45))
        elif mutation == 'text':
            target.update(text='1/2', raw_text='1/2', normalization_basis=None)
            x, y, unused_right, bottom = target['box']
            draw.rectangle([x+5, y+5, x+12, bottom-5], fill=(220, 220, 220))
        elif mutation == 'overlay':
            draw.rectangle([930, 460, 1170, 555], fill=(80, 80, 80))
            rows.append(dict(text='是否确认', raw_text='是否确认', normalization_basis=None,
                             confidence=.99, box=[950, 480, 1140, 525]))
        elif mutation == 'occluded_input_center':
            x, y, right, bottom = target['box']
            cx, cy = round((x+right)/2), round((y+bottom)/2)
            draw.rectangle([cx-4, cy-4, cx+4, cy+4], fill=(220, 40, 40))
        elif mutation == 'missing_complete_marker':
            # This source row's real glyphs remain inside the viewport after
            # -30. An OCR rectangle touching its safety margin is not clipping.
            draw.rectangle([811, 279, 1080, 316], fill=(45, 45, 45))
            rows = [row for row in rows if row['text'] != '累计使用2次特权赋予']
        else:
            raise ValueError('unknown declared mutation')
        declaration += '; DECLARED NEGATIVE mutation=' + mutation
    result = _frame(image, rows, native_name=name, declaration=declaration)
    image.close()
    return result


def ready_canvas():
    """Only the declared prerequisite stage; no native preparation claim."""
    rows = [dict(text='备战阶段', confidence=.99, box=[420, 28, 520, 64]),
            dict(text='1-1', confidence=.99, box=[530, 28, 610, 64]),
            dict(text='商店', confidence=.99, box=[60, 750, 130, 790]),
            dict(text='出战', confidence=.99, box=[1680, 950, 1800, 990])]
    with Image.new('RGB', (1920, 1080), (45, 45, 45)) as image:
        return _frame(image, rows, page='preparation', declaration='declared empty preparation')


def action_for(request, *, label='0/2', delta=-120):
    rows = request['observation']['rows']
    target = [row for row in rows if row['text'] == label]
    chapter = [row for row in rows if row['text'] == '第4章']
    if len(target) != 1 or len(chapter) != 1:
        raise ValueError('replay action requires actual unique row')
    x, y, right, bottom = target[0]['box']
    proof = dict(control_id=guards.TASK_LIST_SCROLL_CONTROL, source='observed_screen',
        snapshot_id=request['snapshot_id'], capture_request_id=request['observation']['capture_request_id'],
        frame_id=request['observation']['frame_id'], text=label, bounds=target[0]['box'].copy(),
        chapter_text='第4章', chapter_bounds=chapter[0]['box'].copy(), list_bounds=LIST_BOUNDS.copy())
    return dict(type='scroll', args=[(x+right)/2, (y+bottom)/2, delta], expected_page='unknown',
        guard_texts=['创业指南', '第4章', label], target_evidence=proof,
        reason='当前完整唯一列表文字中心的一次受检滚动；以原生多行和滚动条位移复核')


@contextlib.contextmanager
def worker_fixture(*, pair='one', before_mutation=None, after_mutation=None,
                   before_name=None, after_name=None, root_counter_boxes=False, delta=-120,
                   label='0/2'):
    names = ('guard-source', 'scroll-one-before', 'scroll-one-after') if pair == 'one' else (
        'scroll-one-after', 'scroll-two-before', 'scroll-two-after')
    frames = dict(ready=ready_canvas(),
        source=native_canvas(names[0], root_counter_boxes=root_counter_boxes),
        current=native_canvas(before_name or names[1], mutation=before_mutation,
                              root_counter_boxes=root_counter_boxes),
        after=native_canvas(after_name or names[2], mutation=after_mutation,
                            root_counter_boxes=root_counter_boxes))
    by_digest = {item['observation']['snapshot_id']: item for item in frames.values()}
    fixture = compatibility.RuntimeCompatibilityTests()
    with fixture.manual_bridge_fixture() as (runtime, records, owner, control, reader):
        control.published, control.mutation_attempts = [], []
        control.action_index, control.post_reads, control.reader_calls = 0, 0, 0
        control.current_frame, control.expected_input = 'ready', None
        control.result_mutator, control.on_input_receipt = None, None
        control.lock_depth, control.lock_acquisitions = 0, 0
        control.input_locks, control.receipt_locks = [], []
        mutex = threading.RLock()

        @contextlib.contextmanager
        def submission_lock():
            with mutex:
                control.lock_depth += 1
                control.lock_acquisitions += 1
                try:
                    yield
                finally:
                    control.lock_depth -= 1

        control.submission_lock = submission_lock
        control.validate_actions = lambda actions: [dict(type=action['type'],
            args=[float(value) for value in action.get('args', [])]) for action in actions]
        write_json = control.write_json

        def write(path, value):
            write_json(path, value)
            request = value.get('request', {}) if isinstance(value, dict) else {}
            if (Path(path).parent.name == 'request-ledger' and value.get('result') is None
                    and any(action['type'] not in ('observe', 'wait') for action in request.get('actions', []))):
                control.receipt_locks.append(control.lock_depth > 0)
                if control.on_input_receipt is not None:
                    callback, control.on_input_receipt = control.on_input_receipt, None
                    callback(request)

        control.write_json = write

        def read(path, force=False, *, scope='full', **unused):
            control.reader_calls += 1
            digest = hashlib.sha256(Path(path).read_bytes()).hexdigest()
            return copy.deepcopy(by_digest[digest]['observation'])

        reader.read = read

        def inert(value):
            if control.lock_depth <= 0:
                raise AssertionError('Entry publisher did not own its submission lease')
            actions = copy.deepcopy(value.get('actions', []))
            mutations = [action for action in actions if action['type'] not in ('observe', 'wait')]
            control.mutation_attempts.extend(mutations)
            if mutations:
                if mutations != [control.expected_input] or mutations[0]['type'] != 'scroll':
                    raise AssertionError('native-scroll replay received a different game command')
                control.action_index += 1
                control.input_locks.append(control.lock_depth > 0)
                control.current_frame = 'after'
            elif control.action_index:
                control.post_reads += 1
            frame = frames[control.current_frame]
            payload, digest = frame['payload'], frame['observation']['snapshot_id']
            frame_id = uuid.uuid4().hex
            directory = runtime / 'frames' / (hashlib.sha256(value['id'].encode()).hexdigest() + '-' + frame_id)
            directory.mkdir(parents=True)
            for name in ('original.png', 'preview.png'):
                (directory / name).write_bytes(payload)
            control.published.append(copy.deepcopy(value))
            result = dict(id=value['id'], ok=True, completed=actions,
                input_attempted=bool(mutations), attempted_actions=mutations, offline_fixture_receipt=True,
                observation=dict(frame_protocol=1, request_id=value['id'], frame_id=frame_id,
                    captured_at=runner.now(), snapshot=str(directory / 'preview.png'),
                    original=str(directory / 'original.png'), snapshot_sha256=digest, original_sha256=digest,
                    snapshot_size=[1920, 1080], original_size=[1920, 1080]))
            if control.result_mutator is not None:
                control.result_mutator(value, result)
            control.write_json(runtime / 'result.json', result)

        control.publish_request = inert
        control.write_json(runtime / 'runner-owner.json', owner)
        state = entry.read_json(runtime / 'runner-state.json')
        state['preparation_stage'] = '1-1'
        control.write_json(runtime / 'runner-state.json', state)
        worker = fixture.frame_worker(runtime, records, owner, control, reader)
        preparation_fixture.runner = runner
        preparation_fixture.ready_fixture(worker, ROOT)
        worker.last_preparation_stage = '1-1'
        worker.profile_wait_id, worker.profile_wait_kind = None, None

        def publish(**changes):
            worker.state.update(changes)
            saved = entry.read_json(runtime / 'runner-state.json')
            saved.update(match_id=worker.active_match_id, preparation_stage='1-1',
                         decision_request=copy.deepcopy(worker.state.get('decision_request')))
            control.write_json(runtime / 'runner-state.json', saved)

        worker.publish = publish
        observed = worker.observe()
        worker.ask(observed, 'preparation_strategy', '声明空场与已完成的公开manual交接前置')
        request = worker.state['decision_request']
        worker.review_preparation(dict(proof=dict(source='observed_screen', snapshot_id=request['snapshot_id'],
            evidence_file=request['evidence_file'], resume_epoch=worker.epoch()),
            value=dict(reviewer='supervising_agent', phase='rewards', stage='1-1', completed=True,
                all_claimed=True, rescanned_after_claim=True, findings='声明空场前置；不重测已实机通过的交接路径')))
        rewards = runner.begin_manual_phase(runtime, owner, control, 'manual-one', 'rewards', reader=reader)
        runner.finish_manual_phase(runtime, owner, control, rewards['checkpoint_id'], [],
            dict(reviewer='supervising_agent', phase='rewards', stage='1-1', completed=True,
                all_claimed=True, rescanned_after_claim=True, findings='声明空场的既有阶段顺序前置'), reader=reader)
        control.current_frame = 'source'
        checkpoint = runner.begin_manual_phase(runtime, owner, control, 'manual-one', 'startup_guide', reader=reader)
        observed = worker.observe()
        worker.state['decision_request'] = None
        worker.ask(observed, 'unknown_page', '当前原生创业指南的受检列表滚动')
        request = worker.state['decision_request']
        reply = {key: request[key] for key in ('request_id', 'snapshot_id', 'resume_epoch')}
        reply['actions'] = [action_for(request, delta=delta, label=label)]
        control.expected_input = dict(type='scroll', args=[float(value) for value in reply['actions'][0]['args']])
        control.current_frame = 'current'
        yield SimpleNamespace(worker=worker, control=control, reader=reader, runtime=runtime,
            records=records, owner=owner, request=request, reply=reply, checkpoint=checkpoint, frames=frames)


def job_kwargs(bundle, *, reply=None, step_id=None):
    return dict(manual_id='manual-one', step_id=step_id or uuid.uuid4().hex, operation='reviewed_plan',
        checkpoint_id=bundle.checkpoint['checkpoint_id'], reply=bundle.reply if reply is None else reply,
        wait_seconds=0)


def manual_job(bundle, *, reply=None, after_queue=None):
    kwargs = job_kwargs(bundle, reply=reply)
    queued = steps.submit(bundle.runtime, bundle.owner, bundle.control, **kwargs)
    if queued['status'] != 'queued':
        raise AssertionError('manual step did not queue: ' + repr(queued))
    if after_queue is not None:
        after_queue()
    if not steps.process(bundle.worker):
        raise AssertionError('owning Worker did not consume its queued manual step')
    return steps.submit(bundle.runtime, bundle.owner, bundle.control, **kwargs), kwargs


def remember(bundle, case, returned, before):
    EVIDENCE.append(dict(case=case, status=returned['status'], pending=returned.get('pending'),
        task_scroll=(returned.get('result') or {}).get('task_scroll'),
        input_publications=len(bundle.control.mutation_attempts),
        entry_publications=len(bundle.control.published)-before,
        extra_post_observations=bundle.control.post_reads,
        source_frames={name: dict(native_name=frame['native_name'], declaration=frame['declaration'])
                       for name, frame in bundle.frames.items() if name != 'ready'},
        postcondition=copy.deepcopy((getattr(bundle.worker, 'task_scroll_result', None) or {}).get('postcondition')),
        submitted_wheel_delta=bundle.reply['actions'][0]['args'][2], retained_native_pair_wheel_delta=-120,
        native_page_overwritten=False, real_game_inputs=0))


def normal_review_reply(worker, phase):
    """A declared supervisor answer, consumed by the normal review path."""
    request = worker.state['decision_request']
    value = dict(reviewer='supervising_agent', completed=True, phase=phase, stage='1-1',
        findings='声明监督复核事实，仅验当前普通阶段出口；保留裁片不证明实机任务末尾已核。')
    if phase == 'rewards':
        value.update(all_claimed=True, rescanned_after_claim=True)
    elif phase == 'startup_guide':
        value.update(entry_index=2, rewards_claimed=True,
            goals=[dict(condition='累计使用2次特权赋予卡升级进阶装备', condition_met=False,
                        reward_claimed=False, progress='0/2')])
    else:
        raise ValueError('normal replay reviews only rewards and startup_guide')
    return dict(request_id=request['request_id'], snapshot_id=request['snapshot_id'],
        resume_epoch=worker.epoch(), context_update=dict(preparation_review=dict(
            proof=dict(source='observed_screen', snapshot_id=request['snapshot_id'],
                evidence_file=request['evidence_file'], resume_epoch=worker.epoch(),
                capture_request_id=request['observation']['capture_request_id']), value=value)),
        actions=[dict(type='finish_preparation_review', reason='只消费当前鲜帧监督复核，不附带游戏输入')])


@contextlib.contextmanager
def normal_worker_fixture():
    """Actual constructor/publish/reviews; only transport and scenes adapted.

    This fixture starts on a declared preparation frame. The already verified
    native icon opening is a scene handoff, not a repeated navigation test.
    No completed preparation entry is inserted into Worker state or context.
    """
    # Local import avoids a module cycle: recovery imports native_canvas.
    from test_currency_wars_business_guide_recovery import (
        business_reply, recovery_fixture, submit_decision)
    with recovery_fixture() as (worker, control, evidence):
        after = native_canvas('scroll-one-after')
        evidence['frames']['normal_scroll_after'] = after
        evidence['by_digest'][after['observation']['snapshot_id']] = after
        control.normal_scroll_expected = None
        control.normal_before_final_status = None
        control.normal_status_injections = []
        original_publish, original_write = control.publish_request, control.write_json

        def write(path, value):
            original_write(path, value)
            request = value.get('request', {}) if isinstance(value, dict) else {}
            if (Path(path).parent.name == 'business-receipts' and value.get('result') is None
                    and any(action.get('type') == 'scroll' for action in request.get('actions', []))
                    and control.normal_before_final_status is not None):
                callback, control.normal_before_final_status = control.normal_before_final_status, None

                def at_status_return():
                    if control.lock_depth <= 0:
                        raise AssertionError('late status injection did not retain the actual Entry lease')
                    control.normal_status_injections.append(dict(lock_depth=control.lock_depth,
                        phase_before=worker.preparation_checklist(worker.last_observation)['phase']))
                    callback()

                control.before_status_return = at_status_return

        def publish(request):
            actions = request.get('actions', [])
            physical = [item for item in actions if item['type'] not in ('observe', 'wait')]
            if not any(item['type'] == 'scroll' for item in physical):
                return original_publish(request)
            if (control.lock_depth <= 0 or physical != [control.normal_scroll_expected]
                    or request['kind'] != 'actions' or request['handoff'] is not False
                    or control.status()['paused']):
                raise AssertionError('normal replay received an unexpected or unguarded scroll')
            control.assert_owner(request['chat_id'], request['run_token'])
            control.published.append(copy.deepcopy(request))
            control.inputs.extend(copy.deepcopy(physical))
            control.frame = 'normal_scroll_after'
            frame = evidence['frames'][control.frame]
            frame_id = uuid.uuid4().hex
            directory = worker.run / 'frames' / (hashlib.sha256(request['id'].encode()).hexdigest() + '-' + frame_id)
            directory.mkdir(parents=True)
            for name in ('preview.png', 'original.png'):
                (directory / name).write_bytes(frame['payload'])
            digest = frame['observation']['snapshot_id']
            result = dict(id=request['id'], ok=True, completed=copy.deepcopy(actions),
                input_attempted=True, attempted_actions=copy.deepcopy(physical), offline_fixture_receipt=True,
                observation=dict(frame_protocol=1, request_id=request['id'], frame_id=frame_id,
                    captured_at=runner.now(), snapshot=str(directory / 'preview.png'),
                    original=str(directory / 'original.png'), snapshot_sha256=digest, original_sha256=digest,
                    snapshot_size=[1920, 1080], original_size=[1920, 1080]))
            control.write_json(worker.run / 'result.json', result)

        control.write_json, control.publish_request = write, publish
        control.frame = 'preparation'
        worker.tick(worker.observe())
        if worker.state['decision_request']['kind'] != 'business_resume':
            raise AssertionError('normal fixture did not construct its actual business review')
        if not submit_decision(worker, business_reply(worker))['ok'] or not worker.tick_decision():
            raise AssertionError('actual current business review was not consumed')
        if worker.business_needs_review or worker.preparation_reviews:
            raise AssertionError('business review must not manufacture completed preparation reviews')
        worker.tick(worker.observe())
        if worker.state['decision_request']['preparation_checklist']['phase'] != 'rewards':
            raise AssertionError('normal fixture did not request the initial rewards phase')
        reward_request = copy.deepcopy(worker.state['decision_request'])
        if not submit_decision(worker, normal_review_reply(worker, 'rewards'))['ok'] or not worker.tick_decision():
            raise AssertionError('normal current rewards answer was not consumed')
        if worker.preparation_checklist(worker.last_observation)['phase'] != 'startup_guide':
            raise AssertionError('actual normal reward review did not reach startup_guide')
        reward_review = copy.deepcopy(worker.preparation_reviews['rewards'])
        # Declared native opening result: no icon input, navigation trace or
        # completion is fabricated. The actual new ask owns this native frame.
        control.frame = 'source'
        worker.tick(worker.observe())
        request = copy.deepcopy(worker.state['decision_request'])
        if request['kind'] != 'unknown_page' or request['observation']['page'] != 'unknown':
            raise AssertionError('normal guide request must retain native unknown')
        reply = {key: request[key] for key in ('request_id', 'snapshot_id', 'resume_epoch')}
        reply['actions'] = [action_for(request)]
        control.normal_scroll_expected = dict(type='scroll', args=[float(value) for value in reply['actions'][0]['args']])
        control.frame = 'current'
        yield SimpleNamespace(worker=worker, control=control, evidence=evidence,
            request=request, reply=reply, reward_request=reward_request, reward_review=reward_review)


class NativeScrollConsumerTests(unittest.TestCase):
    def test_both_retained_native_pairs_verify_real_displacement_once(self):
        for pair, delta in (('one', -120), ('two', -120), ('one', -1200)):
            # -1200 checks one Entry publication only. Its returned pixels are
            # an explicitly declared effect fixture, not native -1200 evidence.
            with self.subTest(pair=pair, delta=delta), worker_fixture(
                    pair=pair, root_counter_boxes=pair == 'one', delta=delta) as bundle:
                diagnosis_bytes = (EVIDENCE_DIR / 'diagnosis.json').read_bytes()
                original = native_sources()[0]
                self.assertEqual(original['scroll_one']['result']['task_scroll']['status'], 'pending')
                self.assertEqual(original['scroll_two']['result']['task_scroll']['status'], 'pending')
                before = len(bundle.control.published)
                returned, kwargs = manual_job(bundle)
                self.assertEqual(returned['status'], 'returned', returned)
                self.assertFalse(returned['pending'], returned)
                result = returned['result']['task_scroll']
                self.assertEqual((result['status'], result['outcome'], result['shift_y']),
                                 ('verified', '位移已核实', -30), returned)
                self.assertEqual(result['verification_reads'], 0)
                self.assertFalse(result['automatic_phase_completion'])
                self.assertFalse(result['input_resent'])
                self.assertEqual(bundle.control.mutation_attempts, [bundle.control.expected_input])
                self.assertEqual(bundle.control.input_locks, [True])
                self.assertEqual(bundle.control.receipt_locks, [True])
                self.assertEqual(bundle.control.post_reads, 0)
                self.assertEqual(bundle.worker.last_observation['page'], 'unknown')
                self.assertEqual(bundle.worker.preparation_checklist(bundle.worker.last_observation)['phase'], 'startup_guide')
                self.assertNotIn('startup_guide', bundle.worker.preparation_reviews)
                self.assertEqual(len(bundle.control.published)-before, 2)
                receipt = runner.await_existing_receipt(bundle.runtime, bundle.control, result['input_request_id'], 0)
                physical = [item for item in receipt['result']['completed'] if item['type'] not in ('observe', 'wait')]
                self.assertEqual(physical, [bundle.control.expected_input])
                record = Path(result['record_file'])
                frozen, count = record.read_bytes(), len(bundle.control.published)
                self.assertEqual(steps.submit(bundle.runtime, bundle.owner, bundle.control, **kwargs), returned)
                self.assertFalse(steps.process(bundle.worker))
                self.assertEqual(len(bundle.control.published), count)
                self.assertEqual(record.read_bytes(), frozen)
                self.assertEqual((EVIDENCE_DIR / 'diagnosis.json').read_bytes(), diagnosis_bytes)
                if pair == 'one':
                    old = next(row['box'] for row in bundle.frames['current']['observation']['rows'] if row['text'] == '0/2')
                    fresh = next(row['box'] for row in bundle.frames['after']['observation']['rows'] if row['text'] == '0/2')
                    self.assertEqual((old[3]-old[1], fresh[3]-fresh[1]), (31, 30))
                else:
                    self.assertFalse(any(row['text'] == '0/2' for row in bundle.worker.last_observation['rows']))
                    self.assertTrue(any(row['text'] == 'U/Z' for row in bundle.worker.last_observation['rows']))
                case = 'retained_native_pair_' + pair if delta == -120 else 'declared_maximum_wheel_with_native_effect_pixels'
                remember(bundle, case, returned, before)

    def test_preinput_motion_cover_text_source_and_phase_fail_closed(self):
        cases = ('moved', 'cover', 'text', 'overlay', 'occluded_input_center',
                 'source_bytes', 'phase_after_queue', 'phase_inside_entry_lock')
        for case in cases:
            options = dict(before_name='scroll-one-after') if case == 'moved' else (
                dict(before_mutation=case) if case in ('cover', 'text', 'overlay', 'occluded_input_center') else {})
            with self.subTest(case=case), worker_fixture(**options) as bundle:
                after_queue = None
                if case == 'source_bytes':
                    after_queue = lambda: Path(bundle.request['original_png']).write_bytes(bundle.frames['after']['payload'])
                elif case == 'phase_after_queue':
                    after_queue = bundle.worker.preparation_reviews.clear
                elif case == 'phase_inside_entry_lock':
                    def invalidate(unused):
                        path = bundle.runtime / 'manual-results' / (bundle.checkpoint['checkpoint_id'] + '.json')
                        changed = entry.read_json(path)
                        changed['phase'] = 'rewards'
                        bundle.control.write_json(path, changed)
                    bundle.control.on_input_receipt = invalidate
                before = len(bundle.control.published)
                returned, unused = manual_job(bundle, after_queue=after_queue)
                self.assertEqual(returned['status'], 'refused', returned)
                self.assertEqual(bundle.control.mutation_attempts, [])
                remember(bundle, case, returned, before)

    def test_missing_reverse_covered_and_changed_target_postconditions_stay_pending(self):
        for case in ('no_motion', 'reverse', 'overlay', 'text', 'missing_complete_marker'):
            options = dict(after_name='scroll-one-before') if case == 'no_motion' else (
                dict(pair='two', after_name='scroll-one-before') if case == 'reverse' else dict(after_mutation=case))
            if case == 'missing_complete_marker':
                options['label'] = '累计使用2次特权赋予'
            with self.subTest(case=case), worker_fixture(**options) as bundle:
                before = len(bundle.control.published)
                returned, kwargs = manual_job(bundle)
                self.assertEqual(returned['status'], 'returned', returned)
                self.assertTrue(returned['pending'], returned)
                result = returned['result']['task_scroll']
                self.assertEqual((result['status'], result['outcome']), ('pending', '效果未确认'))
                self.assertEqual(result['verification_reads'], 0)
                self.assertEqual(bundle.control.mutation_attempts, [bundle.control.expected_input])
                self.assertEqual(bundle.control.post_reads, 0)
                count = len(bundle.control.published)
                self.assertEqual(steps.submit(bundle.runtime, bundle.owner, bundle.control, **kwargs), returned)
                self.assertEqual(len(bundle.control.published), count)
                remember(bundle, 'post_' + case, returned, before)

    def test_outside_list_and_invalid_wheel_payloads_refuse_before_job(self):
        for case in ('left_panel', 'list_bounds', 'missing_text', 'outside_point', 'nonmultiple', 'over_limit'):
            with self.subTest(case=case), worker_fixture() as bundle:
                reply = copy.deepcopy(bundle.reply)
                action = reply['actions'][0]
                if case == 'left_panel':
                    reply['actions'] = [action_for(bundle.request, label='进行中')]
                elif case == 'list_bounds':
                    action['target_evidence']['list_bounds'][0] -= 1
                elif case == 'missing_text':
                    action['target_evidence'].pop('text')
                elif case == 'outside_point':
                    action['args'][0] = action['target_evidence']['bounds'][2]
                elif case == 'nonmultiple':
                    action['args'][2] = -121
                else:
                    action['args'][2] = -1320
                before = len(bundle.control.published)
                jobs = list((bundle.runtime / 'manual-steps').glob('*.json'))
                reader_calls = bundle.control.reader_calls
                pause_before = bundle.control.status()['paused']
                with self.assertRaises(ValueError):
                    steps.submit(bundle.runtime, bundle.owner, bundle.control, **job_kwargs(bundle, reply=reply))
                self.assertEqual(list((bundle.runtime / 'manual-steps').glob('*.json')), jobs)
                self.assertEqual(len(bundle.control.published), before)
                self.assertEqual(bundle.control.reader_calls, reader_calls)
                self.assertEqual(bundle.control.status()['paused'], pause_before)
                self.assertEqual(bundle.control.mutation_attempts, [])
                EVIDENCE.append(dict(case=case, boundary='public_manual_submit_preflight',
                    new_jobs=0, captures=0, game_inputs=0, pause_changed=False))

    def test_normal_decide_scroll_and_current_reviews_reach_inventory(self):
        from test_currency_wars_business_guide_recovery import escape_reply, submit_decision
        with normal_worker_fixture() as bundle:
            worker, control = bundle.worker, bundle.control
            epoch_path = worker.run / 'runner-resume-epoch.json'
            epoch_bytes, match_id = epoch_path.read_bytes(), worker.active_match_id
            self.assertIsNone(runner.manual_state(worker.run))
            self.assertIsNone(getattr(worker, 'manual_step_context', None))
            self.assertEqual(worker.state['control_mode'], 'waiting_decision')
            self.assertEqual(bundle.reward_review['origin'], 'supervising_agent')
            self.assertEqual(bundle.reward_review['proof']['snapshot_id'], bundle.reward_request['snapshot_id'])
            self.assertEqual(worker.history[bundle.reward_request['snapshot_id']]['page'], 'preparation')
            self.assertEqual(control.inputs, [])
            self.assertTrue(submit_decision(worker, bundle.reply)['ok'])
            self.assertTrue(worker.tick_decision())
            result = copy.deepcopy(worker.task_scroll_result)
            self.assertEqual((result['origin'], result['manual_step_id'], result['status'], result['shift_y']),
                             ('normal_decide', None, 'verified', -30))
            self.assertFalse(result['automatic_phase_completion'])
            self.assertEqual(result['verification_reads'], 0)
            self.assertEqual(control.inputs, [control.normal_scroll_expected])
            receipt = runner.await_existing_receipt(worker.run, control, result['input_request_id'], 0)
            self.assertEqual([item for item in receipt['result']['completed']
                              if item['type'] not in ('observe', 'wait')], [control.normal_scroll_expected])
            self.assertEqual(worker.preparation_checklist(worker.last_observation)['phase'], 'startup_guide')
            worker.tick(worker.observe())
            guide_request = copy.deepcopy(worker.state['decision_request'])
            self.assertEqual(guide_request['preparation_checklist']['phase'], 'startup_guide')
            self.assertEqual(guide_request['observation']['page'], 'unknown')
            self.assertTrue(submit_decision(worker, normal_review_reply(worker, 'startup_guide'))['ok'])
            self.assertTrue(worker.tick_decision())
            self.assertEqual(control.inputs, [control.normal_scroll_expected])
            guide_review = copy.deepcopy(worker.preparation_reviews['startup_guide'])
            self.assertEqual(guide_review['proof']['snapshot_id'], guide_request['snapshot_id'])
            self.assertNotIn('rewards', worker.preparation_reviews)
            self.assertEqual(worker.preparation_checklist(worker.last_observation)['phase'], 'rewards')
            worker.tick(worker.observe())
            self.assertTrue(submit_decision(worker, escape_reply(worker))['ok'])
            self.assertTrue(worker.tick_decision())
            self.assertEqual(control.inputs, [control.normal_scroll_expected, dict(type='key', args=[27.])])
            self.assertEqual(worker.last_observation['page'], 'preparation')
            self.assertEqual(worker.preparation_reviews['startup_guide'], guide_review)
            worker.tick(worker.observe())
            fresh_rewards = copy.deepcopy(worker.state['decision_request'])
            self.assertEqual(fresh_rewards['preparation_checklist']['phase'], 'rewards')
            self.assertNotEqual(fresh_rewards['observation']['capture_request_id'],
                                bundle.reward_request['observation']['capture_request_id'])
            self.assertTrue(submit_decision(worker, normal_review_reply(worker, 'rewards'))['ok'])
            self.assertTrue(worker.tick_decision())
            self.assertEqual(worker.preparation_reviews['startup_guide'], guide_review)
            worker.tick(worker.observe())
            final_request = worker.state['decision_request']
            self.assertEqual(final_request['kind'], 'preparation_strategy')
            self.assertEqual(final_request['preparation_checklist']['phase'], 'inventory_cleanup')
            self.assertFalse(final_request['preparation_checklist']['economy_allowed'])
            self.assertEqual(worker.active_match_id, match_id)
            self.assertEqual(epoch_path.read_bytes(), epoch_bytes)
            self.assertIsNone(runner.manual_state(worker.run))
            self.assertFalse((worker.run / 'manual-results').exists())
            self.assertEqual(bundle.evidence['old_archive'].read_bytes(), bundle.evidence['old_bytes'])
            EVIDENCE.append(dict(case='normal_scroll_current_reviews_to_inventory',
                boundary='actual_Worker_constructor_publish_tick_decide_reviews_Entry',
                normal_scroll=result, input_commands=copy.deepcopy(control.inputs),
                phase_sequence=['rewards', 'startup_guide', 'startup_guide', 'rewards', 'inventory_cleanup'],
                manual_id=None, epoch_unchanged=True, historical_unknown_unchanged=True,
                guide_opening_scene_declared=True, supervisor_review_facts_declared=True,
                native_crops_do_not_prove_real_guide_tail_review=True,
                maximum_wheel_native_acceptance=False, real_game_inputs=0))

    def test_normal_scroll_last_entry_status_phase_and_takeover_refuse_input(self):
        from test_currency_wars_business_guide_recovery import submit_decision
        for case in ('phase', 'takeover'):
            with self.subTest(case=case), normal_worker_fixture() as bundle:
                worker, control = bundle.worker, bundle.control
                self.assertTrue(submit_decision(worker, bundle.reply)['ok'])

                def invalidate():
                    if case == 'phase':
                        worker.preparation_reviews.pop('rewards')
                    else:
                        runner.latch_manual(worker.run, '声明最后status期间的新接管', uuid.uuid4().hex)
                        control.latch_pause('声明最后status期间的新接管')

                control.normal_before_final_status = invalidate
                with self.assertRaises((ValueError, RuntimeError)):
                    worker.tick_decision()
                self.assertEqual(len(control.normal_status_injections), 1)
                self.assertEqual(control.normal_status_injections[0]['phase_before'], 'startup_guide')
                self.assertEqual(control.inputs, [])
                result = worker.task_scroll_result
                self.assertEqual((result['origin'], result['manual_step_id'], result['status']),
                                 ('normal_decide', None, 'refused'))
                self.assertFalse(result['publication_attempted'])
                self.assertFalse(result['input_resent'])
                self.assertEqual(bundle.evidence['old_archive'].read_bytes(), bundle.evidence['old_bytes'])
                EVIDENCE.append(dict(case='normal_scroll_late_' + case, phase_before='startup_guide',
                    injection='actual_Entry_lock_last_status_after_business_archive',
                    injection_count=1, input_commands=[], status='refused', real_game_inputs=0))


if __name__ == '__main__':
    unittest.main()
