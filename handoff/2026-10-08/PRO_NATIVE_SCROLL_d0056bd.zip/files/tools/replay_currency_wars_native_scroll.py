"""Exact offline consumers for retained PR32 scroll pairs and lease recovery.

Replay four manual native-scroll methods, two normal scroll/phase-exit methods
and four business-guide recovery methods only. No old manual-flow or navigation suite, live game, controller,
installation, GUI, or readiness mutation. Native crops and offline OCR retain
separate provenance; unavailable full frames and the rejected frame stay absent.
"""
from __future__ import annotations

import argparse
import importlib.metadata
import io
import json
from pathlib import Path
import platform
import subprocess
import sys
import time
import unittest

import replay_currency_wars_task_scroll as base


ROOT = Path(__file__).resolve().parents[1]
PARENT = 'd0056bdc03bc967d5138781f29518a970b7ceab9'
EVIDENCE_COMMIT = '0312619dedc6d7ad2bf7b21dcc5b95dec6b8bf89'
SELECTION = (
    'test_currency_wars_native_scroll.NativeScrollConsumerTests.test_both_retained_native_pairs_verify_real_displacement_once',
    'test_currency_wars_native_scroll.NativeScrollConsumerTests.test_preinput_motion_cover_text_source_and_phase_fail_closed',
    'test_currency_wars_native_scroll.NativeScrollConsumerTests.test_missing_reverse_covered_and_changed_target_postconditions_stay_pending',
    'test_currency_wars_native_scroll.NativeScrollConsumerTests.test_outside_list_and_invalid_wheel_payloads_refuse_before_job',
    'test_currency_wars_native_scroll.NativeScrollConsumerTests.test_normal_decide_scroll_and_current_reviews_reach_inventory',
    'test_currency_wars_native_scroll.NativeScrollConsumerTests.test_normal_scroll_last_entry_status_phase_and_takeover_refuse_input',
    'test_currency_wars_business_guide_recovery.BusinessGuideRecoveryTests.test_current_guide_escape_then_original_fresh_business_resume',
    'test_currency_wars_business_guide_recovery.BusinessGuideRecoveryTests.test_invalid_recovery_payloads_and_fresh_frame_changes_refuse_input',
    'test_currency_wars_business_guide_recovery.BusinessGuideRecoveryTests.test_entry_publication_rechecks_pause_deadline_and_owner',
    'test_currency_wars_business_guide_recovery.BusinessGuideRecoveryTests.test_unknown_delivery_and_unclosed_panel_never_repeat_escape',
)
SUPPORT = (
    'tools/test_local_runtime_compatibility.py',
    'tools/replay_currency_wars_preparation.py',
    'tools/replay_currency_wars_task_scroll.py',
    'tools/test_currency_wars_native_scroll.py',
    'tools/replay_currency_wars_native_scroll.py',
    'tools/test_currency_wars_business_guide_recovery.py',
)


def sources():
    from currency_wars_source_guard import production_files
    runtime = sorted(production_files(ROOT))
    names = sorted(set(runtime) | set(SUPPORT))
    return {name: base.sha(ROOT / name) for name in names}, runtime


def artifacts():
    from test_currency_wars_native_scroll import ASSET_SHA256, EVIDENCE_DIR
    names = [(EVIDENCE_DIR / name).relative_to(ROOT).as_posix() for name in ASSET_SHA256]
    if (ROOT / 'docs/GAME_KNOWLEDGE.json').exists():
        names.append('docs/GAME_KNOWLEDGE.json')
    return {name: base.sha(ROOT / name) for name in sorted(names)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--require-runtime-resources', action='store_true',
        help='Also require actual complete runtime resources/provider; a public checkout may omit them')
    args = parser.parse_args()
    packages = {}
    for name in ('numpy', 'Pillow', 'psutil', 'opencv-python', 'rapidocr-onnxruntime', 'onnxruntime'):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    report = dict(schema='currency-wars-native-scroll/v1', basis_commit=PARENT,
        evidence_commit=EVIDENCE_COMMIT,
        source_binding_authority='Exact before/after bytes; HEAD alone does not certify uncommitted source.',
        environment=dict(system=platform.system(), python=platform.python_version(), packages=packages),
        execution_scope='Ten exact methods: four manual scroll, two normal scroll/phase exit, four business-guide recovery.',
        game_inputs=0, controllers_started=0, new_game_captures=0, native_ocr_calls_during_replay=0,
        online_model_called=False, candidate_installed=False, ready_changed=False,
        require_runtime_resources=args.require_runtime_resources,
        old_navigation_suite_rerun=False, previous_manual_flow_rerun=False,
        public_original_full_game_pngs_available=False,
        rejected_guard_actual_frame_available=False, rejected_guard_actual_frame_replayed=False,
        native_scope='Five unedited 1380x709 crops at [270,186,1650,895]; missing outer pixels are declared padding.',
        ocr_scope='Separately archived real offline OCR on padded 1920x1080 at 1280x720; not ROOT original OCR.',
        larger_wheel_native_acceptance=False, whole_game_speedup=None,
        declared_boundaries=[
            'Manual scroll Worker initialization via frame_worker/ready_fixture and initial manual ownership',
            'Manual scroll Worker.publish same-stage 1-1 state-file adapter',
            'Scroll transport, process/window status and image reader replay',
            'Normal scroll/phase exit and business-guide recovery use actual Worker constructor and publish',
            'Normal Guide opening is a declared scene handoff; supervisor review facts are declared through actual decide/review consumers',
            'Retained crops do not prove the real-game Guide tail has been reviewed or rewards cleared',
            'Outside native crop uses gray padding; no native full-frame equality or OCR accuracy claim',
            'Negative image mutations and maximum-wheel returned effect are expressly declared fixtures'])
    try:
        report['tested_checkout_head'] = subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True, stderr=subprocess.DEVNULL, timeout=5).strip()
    except (OSError, subprocess.SubprocessError):
        report['tested_checkout_head'] = None
    stream = io.StringIO()
    try:
        before, runtime = sources()
        data_before, binding_before = artifacts(), base.runtime_binding()
        report.update(source_sha256=before, source_file_count=len(before),
            runtime_source_files=runtime, runtime_source_count=len(runtime),
            artifact_sha256=data_before, artifact_file_count=len(data_before),
            runtime_resource_sha256=binding_before['resource_sha256'],
            runtime_resource_count=(len(binding_before['resource_sha256'])
                                    if binding_before['resource_sha256'] is not None else None),
            runtime_resource_inventory=binding_before['resource_inventory'],
            runtime_provider=binding_before['runtime_provider'],
            runtime_resource_binding_complete=binding_before['resource_sha256'] is not None,
            runtime_resource_binding_error=binding_before['resource_binding_error'],
            runtime_provider_error=binding_before['runtime_provider_error'])
        loader = unittest.TestLoader()
        suite = loader.loadTestsFromNames(SELECTION)
        if loader.errors or tuple(base.test_ids(suite)) != SELECTION:
            raise ValueError('The exact ten-method selection did not resolve: ' + repr(loader.errors))
        from test_currency_wars_native_scroll import EVIDENCE as native_evidence, native_sources
        from test_currency_wars_business_guide_recovery import EVIDENCE as recovery_evidence
        diagnosis, ocr, unused_payloads = native_sources()
        report['native_evidence_provenance'] = dict(
            frames=diagnosis['frames'], missing_rejected_frame_sha256=diagnosis['guard_failure_actual_frame_sha256'],
            missing_rejected_frame_note=diagnosis['guard_failure_retention_note'],
            ocr_model_sha256=ocr['models'], ocr_packages=ocr['packages'],
            original_reported_scroll_statuses=[diagnosis['scroll_one']['result']['task_scroll']['status'],
                                               diagnosis['scroll_two']['result']['task_scroll']['status']])
        native_evidence.clear()
        recovery_evidence.clear()
        started = time.perf_counter()
        result = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=base.Result).run(suite)
        report['focused_checks'] = dict(selection=list(SELECTION), tests=result.testsRun,
            failures=len(result.failures), errors=len(result.errors), skips=len(result.skipped),
            seconds=time.perf_counter()-started, results=result.outcomes,
            subcase_count=len(result.subcases), subcases=result.subcases,
            failure_details=[dict(test=test.id(), traceback=trace) for test, trace in result.failures + result.errors])
        report['native_scroll_consumer_evidence'] = native_evidence
        report['business_guide_recovery_evidence'] = recovery_evidence
        report['normal_phase_exit_verified'] = any(
            item.get('case') == 'normal_scroll_current_reviews_to_inventory'
            and item.get('phase_sequence', [])[-1:] == ['inventory_cleanup'] for item in native_evidence)
        after, runtime_after = sources()
        data_after, binding_after = artifacts(), base.runtime_binding()
        loaded = sorted({Path(module.__file__).resolve().relative_to(ROOT).as_posix()
            for module in tuple(sys.modules.values()) if getattr(module, '__file__', None)
            and str(module.__file__).endswith('.py') and Path(module.__file__).resolve().is_relative_to(ROOT)})
        report.update(source_set_sha256_before=base.digest(before), source_set_sha256_after=base.digest(after),
            source_sha256_after_differences={name: dict(before=before.get(name), after=after.get(name))
                for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)},
            source_unchanged=before == after and runtime == runtime_after,
            artifacts_unchanged=data_before == data_after,
            optional_runtime_bindings_unchanged=binding_before == binding_after,
            runtime_resources_unchanged=(binding_before['resource_sha256'] == binding_after['resource_sha256']
                and binding_before['resource_inventory'] == binding_after['resource_inventory']
                if binding_before['resource_sha256'] is not None else None),
            runtime_provider_unchanged=(binding_before['runtime_provider'] == binding_after['runtime_provider']
                if binding_before['runtime_provider'] is not None else None),
            loaded_source_files=loaded, loaded_source_closure_missing=sorted(set(loaded)-set(before)),
            runtime_manifest_unchanged=after['tools/currency_wars_runtime_sources.json'] == base.MANIFEST_SHA256)
        report['ok'] = bool(result.wasSuccessful() and not result.skipped
            and report['source_unchanged'] and report['artifacts_unchanged']
            and report['optional_runtime_bindings_unchanged']
            and (not args.require_runtime_resources or report['runtime_resource_binding_complete']
                 and report['runtime_provider'] is not None)
            and not report['loaded_source_closure_missing']
            and report['runtime_manifest_unchanged'] and len(runtime) == 24)
    except Exception as error:
        import traceback
        report.update(ok=False, setup_or_finalization_error=dict(type=type(error).__name__,
            message=str(error), traceback=traceback.format_exc()))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    args.output.with_suffix('.tests.txt').write_text(stream.getvalue(), encoding='utf-8')
    print(json.dumps({key: report.get(key) for key in ('ok', 'source_file_count', 'artifact_file_count',
        'runtime_source_count', 'runtime_resource_count', 'source_set_sha256_before',
        'source_set_sha256_after', 'loaded_source_closure_missing')}
        | {key: (report.get('focused_checks') or {}).get(key)
           for key in ('tests', 'subcase_count', 'failures', 'errors', 'skips', 'seconds')}))
    if not report['ok']:
        print(stream.getvalue())
        if report.get('setup_or_finalization_error'):
            print(report['setup_or_finalization_error']['traceback'])
    return 0 if report['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
