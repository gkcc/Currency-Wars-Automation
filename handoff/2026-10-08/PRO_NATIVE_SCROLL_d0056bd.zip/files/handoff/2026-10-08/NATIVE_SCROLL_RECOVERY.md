# 原生指南滚动与当前对局续接

## 交付结论

本候选的唯一父是 `d0056bdc03bc967d5138781f29518a970b7ceab9`，证据基线是 `0312619dedc6d7ad2bf7b21dcc5b95dec6b8bf89`。完整补丁、全部变更文件、原生裁片、消费者报告、独立代码审查和逐文件 SHA 随同交付；具体候选提交与补丁摘要见 `manifest.json`。这是可供 ROOT 隔离验收的代码候选，尚未宣称发布 PR、Windows 通过、安装完成或实机提速。

本次解决三个相连的阻断：原生白字/灰字的微小渲染差异；滚动后 OCR 框抖动与原目标真实裁切；旧 runtime 退出后 Guide 覆盖造成的业务续接等待。最终出口还补上同一局部滚动守卫在**普通流程当前创业指南阶段**的调用绑定，避免为滚动再次接管、换 epoch 和重读奖励。

ROOT 已实机走通的旧 public manual-flow 路径保持可用，本次不重做其构造与交接。当前推荐路径是：正常 start → 当前指南单 Escape 恢复 → 原 business_resume 全场鲜帧复核 → 普通 rewards → 原 native 第二图标 → 普通受检列表滚动 → 当前指南无输入复核 → 普通 Escape → 全场 rewards 再核 → inventory_cleanup → economy。整个新路径不需要为了滚动创建 manual checkpoint。

阶段完成与任务条件达成是两件事：指南检查可以完成，同时如实保留“特权赋予卡 0/2、条件未达成”。所有已达成奖励是否领空，必须先检查；末尾未知不能填写已领空。

## 冻结事实与证据范围

已逐项读取冻结诊断、review.html、五张原样原生 PNG 及相关消费者。原生裁片范围为 `[270,186,1650,895]`，尺寸 `1380×709`；包内副本与冻结 Git 字节完全一致。没有改色、缩放或用合成图冒充原生证据。

| 项目 | 可确认事实 | 本交付不扩写的部分 |
| --- | --- | --- |
| 首次 marker 拒绝 | 标题 max 5、meanabs 0.026415、changed 0.054193；章节 max 17、meanabs 0.164564、changed 0.071208；计数 RGB 相同；零游戏输入 | 实际拒绝帧已经释放。max 17 来自冻结实测 JSON，本次没有重新取得或重放该帧 |
| 第一笔真实滚动 | `1842beef64834ba0afa330a8b99652c7`，原生 `-120`；计数框高度 31→30；原生字形位移 `-30px` | 历史 `task_scroll` 保持 pending，不回填 verified |
| 第二笔真实滚动 | `85ef10ae7a2f4965bb7c4fc1f93a0e25`，原生 `-120`；原计数行上缘真实裁切；其他任务行仍可读 | 历史 pending 保留；不能把裁切的 U/Z 改写成新的 0/2 OCR |
| 租期结束 | ROOT 说明最后请求后达到原 600 秒 broker 空闲限制，旧 Worker/broker 均 absent，owned runtime 已清理 | 不修改 7200/600 限制，也不把等待维护问题归为本补丁缺陷 |
| 当前业务 | ROOT 最后实读同一第三标准局 1-1，第 4 章 6/7、特权赋予卡 0/2；末尾两任务奖励仍未知 | 现场会继续变化。下面每个动作和复核都必须重新读取当前请求；这些旧数值不是新 proof |

完整原始游戏 PNG 只保留了摘要与 capture/frame 元数据，公开可取得的是面板裁片。测试将裁片放回原坐标，外部缺失区域明确补底；这不等同于取得 ROOT 全屏原图。另存的 `offline-ocr-replay.json` 是对原生裁片进行的一次真实离线 OCR，模型摘要有记录；它不是 ROOT 当时的原 OCR，也没有覆盖历史记录。

## 修复如何限制在当前非关键列表

### 局部外观与位置

标题、章节和任务字形复用已有的原生白字/灰字轮廓与邻域守卫。没有把计数的 `max 4 / mean .06 / changed .06` 套给所有锚点，也没有调整全局 dHash、全局像素门槛或 OCR 置信度。

标题与章节的 OCR 边界允许最多 2px 抖动；任务文字允许最多 8px 的局部框变化。框变化只用于提出比较窗口，实际字形仍须按原像素位置吻合。输入前，目标移动、变字、遮挡、输入点局部曝光改变，都不能以 OCR 框抖动解释后放行。

真实右侧列表范围固定为 `[772,278,1587,876]`，目标必须是其中完整、唯一的实际文字。左侧章节、6/7 或“进行中”不能充作任务列表目标。右侧滚动轨道、连续滑块和列表边轨共同核验实际容器曝光；原输入点必须同时落在原框与当前框内。

### 输入与返回后核验

每笔仍是单个 Entry 滚轮动作。滚轮量限 120 的整数倍，绝对值不超过 1200；不允许附加点击、键盘、预算或阶段完成 context。请求、snapshot、capture、frame、owner、match、epoch、stage、原 deadline、当前 phase、停止与接管优先级继续验证。

返回后用原动作回帧核验，不因为效果未知自动重发，也不新增一个滚动专用轮询器。至少两条属于不同任务卡的完整任务描述必须具有唯一共同像素位移，并且滚动条有方向一致的对应位移。两条同卡换行不能冒充两个任务卡。

原目标若仍完整可见，必须继续核同字形、同文字和共同位移；只有原字形按该位移实际跨过真实列表边界时，才允许它从 OCR 消失或被截成其他字符。单纯 OCR 框越界不算字形裁切。该规则已覆盖“第一笔完整目标被擦除，不得冒称裁切”的负例。

两组保留的原生配对都得到 `shift_y=-30`，分别有四条任务文字见证，滑块位移约 `+19 / +19.5px`。`verified` 只表示这笔列表位移已核实，不表示到达底部、奖励领空、章节完成或整局结束。

`-1200` 是新的有界单笔调用范围。只有 `-120` 已有这两组原生实测；不能推定 `-1200` 必然移动 300px、一次见底或效果已获实机验收。ROOT 可为推进选择一笔 `-1200`，然后按原 ID 与实际后帧核验；若超过当前可证明的行重叠范围，结果仍可能 pending，不能据此盲目重发。

### 普通流程与人工流程的归属

人工路径继续要求当前真实 pending `startup_guide` checkpoint、同 manual-step 和原绑定。新增普通路径只接受 Worker 已生成的当前 `unknown_page` 请求，原生页面仍为 `unknown`，当前清单确为 `startup_guide`，本 epoch 的 rewards 已通过真实复核，且没有 manual intent、manual-step context 或未完成的 business_resume。

普通路径复用同一个视觉守卫、原输入租约、Entry 发布和位移核验。最后发布前再次检查当前 phase 与接管状态；旧请求不能因为最初检查合格而越过之后的新接管。这不是一个能放行任意 unknown 页面或经济动作的标志。

## 现有部署为何不能完成本次关闭恢复

`d0056bd` 在 `business_needs_review=true` 且原生 page 为 `unknown` 时只等待，不创建可提交的普通决策。`unknown` 不在允许业务复核的页面集合中；`business_resume` 请求本身又只接受独立无输入复核，输入入口继续拒绝业务尚待确认时的 Escape。

新 Worker 的当前节点最初为未知，只能由实际备战/商店 HUD 建立。不能用旧 run 的 1-1 造一个 manual binding 再借它关页。原 `recover_overlay` 针对已识别奖励模态，也不能冒充 Guide 恢复。因此，此次“旧 owned runtime 已退出、Guide 仍打开”的入口确有缺口，不能直接套上次业务已通过后的普通 Escape。

修复后仍使用现有 `start` 和 `decide`。Worker 只在完整当前原生指南曝光通过时，生成 `choices.business_recovery='startup_guide_escape'` 的 `unknown_page` 请求，允许一笔 Escape。这个动作不证明同局、不改 epoch、不完成任何准备阶段；关页之后仍要原 `business_resume` 的全场新 proof 和原收据水位。

## ROOT 分段执行的公开接口

以下操作在候选通过 ROOT 独立审查、Windows、安装和原 check-launch 后执行。每段等待原消费者与原收据完成，再读取下一段请求。不要一次性排入整条动作链。

### 变量与当前请求

`$py` 为 ROOT 原项目 Python；当前目录为已安装候选的项目根；`$chatId` 和其他原 start 参数继续沿用 ROOT 已授权配置。`max-matches` 是本 Worker 的局数上限，不能把历史全程总目标机械当成本次剩余上限。由 ROOT 根据原授权与真实已完成局数核定 `$cwAuthorizedRemainingMatches`，包含当前未完局；不默认 1，不重置原总目标。下面不会给未知的余额、阵容、策略或节点填默认值。

使用原公开 start，保持原 Worker 7200 秒上限。broker 的 600 秒空闲限制不是这个参数：

```powershell
& $py -B -X utf8 tools/currency_wars_runner.py start --chat-id $chatId --max-seconds 7200 --max-matches $cwAuthorizedRemainingMatches @cwOriginalContinuationArgs
```

`$cwOriginalContinuationArgs` 仅在原授权包含时才含 `--continue-matches`，否则为空数组；本次上限大于 1 时仍遵守原接口要求。不要使用内部 `_worker` 或手填 `--business-resume-json`。原 start 自行检查旧进程归属及退出证据，并构造续接。本 Worker 的 `matches_confirmed` 从 0 计数，不代表历史已完成局数归零。

从这次 start 返回绑定新 `$runDir`。新 token 从该目录真实 `runner-owner.json` 读取，并核对 run_id/chat_id；不展示 token、不取旧 run 的 token。沿用公开参数：

```powershell
$cwAuth = @('--chat-id', $chatId, '--run-dir', $runDir, '--run-token', $runToken)
& $py -B -X utf8 tools/currency_wars_runner.py status @cwAuth
```

以下 `$q` 始终指刚读取且仍当前的 `decision-request.json`。须与 `status.state.decision_request` 的 request_id、snapshot_id、resume_epoch 一致，且尚未到原 deadline。状态须为 `waiting_decision`，broker ready/foreground 且非 paused/input_halted，没有新 manual intent；文件存在本身不证明它仍当前。

本说明中的 reply 文件使用新的唯一文件名，保存 UTF-8 无 BOM 后通过原 `decide` 提交：

```powershell
if (Test-Path -LiteralPath $replyFile) { throw 'Reply path already exists; choose a new file.' }
[IO.File]::WriteAllText($replyFile, ($reply | ConvertTo-Json -Depth 60), [Text.UTF8Encoding]::new($false))
& $py -B -X utf8 tools/currency_wars_runner.py decide @cwAuth --reply-file $replyFile
```

`decide.ok=true` 只说明提交入队。要看 Worker 的接受结果、原 `input_request_id` 与其收据，不把 `command_id` 当作游戏输入 ID。

### 一、只关闭当前原生指南覆盖

现场先核 `$q.kind='unknown_page'`、`$q.choices.business_recovery='startup_guide_escape'`、`$q.observation.page='unknown'`。只有 Worker 自己生成了此请求才可提交，调用者不向请求补写这个字段。

```powershell
$reply = @{
    request_id = $q.request_id
    snapshot_id = $q.snapshot_id
    resume_epoch = $q.resume_epoch
    actions = @(@{
        type = 'key'
        args = @(27)
        expected_page = 'unknown'
        guard_texts = @('创业指南')
        reason = '关闭本请求已核的原生指南覆盖，随后全场鲜帧独立确认原局续接'
    })
}
```

本恢复 action 恰为上述五个字段，无其他 action 或 context。原 Entry 内仍是一次 Escape 及已有等待；其后的 capture 不把旧 proof 变新。观察当前 runtime 的 `business-guide-recovery.json` 和持久记录中的同 request 文件：只有原输入交付已知且当前回帧证明覆盖关闭，才是 `status=verified/outcome=guide_closed`。`business_resume_approved=false` 和 `automatic_phase_completion=false` 必须保留。

已发布或交付未知时，只按记录中的原 `input_request_id` 查收据；不换新请求重复 Escape。明确零发布的拒绝可在新的真实请求上重新规划，不等于允许重复已尝试输入。

### 二、原业务全场新 proof

关页后等待新的 `$q.kind='business_resume'`。ROOT 读取本请求真实全屏 PNG，确认当前同局依据。`$freshBusiness` 必须是现场独立整理的当前事实，不能来自旧 epoch 的报告。

```powershell
$reply = @{
    request_id = $q.request_id
    snapshot_id = $q.snapshot_id
    resume_epoch = $q.resume_epoch
    context_update = @{
        business_resume = @{
            proof = @{
                source = 'observed_screen'
                snapshot_id = $q.snapshot_id
                capture_request_id = $q.observation.capture_request_id
                evidence_file = $q.evidence_file
                resume_epoch = $q.resume_epoch
            }
            value = @{
                reviewer = 'supervising_agent'
                previous_run_id = $q.choices.previous_run_id
                previous_chat_id = $q.choices.previous_chat_id
                current_chat_id = $q.choices.current_chat_id
                match_id = $q.match_id
                unresolved_requests = @($q.choices.unresolved_requests | ForEach-Object { $_.origin_run_id + ':' + $_.request_id } | Sort-Object)
                prior_outcomes_remain_unknown = $true
                remaining_policy = 'fresh_reviews_and_current_balance'
                disposition = 'same_match'
                continuity_basis = $freshBusiness.continuity_basis
                current_state = $freshBusiness.current_state
            }
        }
    }
    actions = @(@{ type = 'finish_preparation_review'; reason = '仅确认当前同局连续性，准备各阶段仍按当前事实复核' })
}
```

若现场为 preparation/shop，`current_state` 须有当前 `page/stage/coins/level/xp/deployed/roster/selected_strategy`；xp 是两个整数 `[当前经验,升级阈值]`，deployed 为实际 `人数/上限`，roster 为实际非空名字数组。continuity_basis 至少 12 个非空白字符并说明实据。若实际已经离开同局或页面变化，不套 `same_match` 示例，应按原业务消费者给出真实处置。

这笔请求必须在 Escape 之后建立；不能把 Escape 插在旧 business_resume 的 proof/水位之后。业务消费者还会执行本请求后的当前纯 observe，核原水位之后没有其他输入或未知交付。成功后检查 `state.business.resume_review_required=false`，随后从当前 rewards 开始。

### 三、普通奖励复核与第二入口

现场关闭商店并实际全场核空后，在当前 rewards 请求使用独立无输入准备复核。可在 ROOT 当前 PowerShell 会话定义以下纯本地函数；它只构造对象，不提交。后文指南与第二次奖励复核也用它，但每次都传新的 `$q` 和新的实际 `$value`：

```powershell
function New-CwPreparationReply {
    param([object]$Request, [object]$Value)
    return @{
        request_id = $Request.request_id
        snapshot_id = $Request.snapshot_id
        resume_epoch = $Request.resume_epoch
        context_update = @{
            preparation_review = @{
                proof = @{
                    source = 'observed_screen'
                    snapshot_id = $Request.snapshot_id
                    evidence_file = $Request.evidence_file
                    resume_epoch = $Request.resume_epoch
                }
                value = $Value
            }
        }
        actions = @(@{ type = 'finish_preparation_review'; reason = '提交当前节点本阶段的实际无输入复核' })
    }
}
```

第一次奖励的 `$value` 只能在真实核空后构造：

```powershell
$value = @{
    phase = 'rewards'
    stage = $q.battle_stage
    reviewer = 'supervising_agent'
    completed = $true
    findings = $freshRewardFindings
    all_claimed = $true
    rescanned_after_claim = $true
}
$reply = New-CwPreparationReply -Request $q -Value $value
```

当前需实际 page 为 preparation，无未决领奖/腾位效果，无仍可见待领或待选目标。不是因为没有识别出图标就自动领空。

接受后等待清单 `phase='startup_guide'` 的当前 preparation 请求，沿用已验原生第二图标，不重测旧导航套：

```powershell
$reply = @{
    request_id = $q.request_id
    snapshot_id = $q.snapshot_id
    resume_epoch = $q.resume_epoch
    actions = @(@{
        type = 'click_point'
        args = @(1687, 65)
        expected_page = 'preparation'
        guard_texts = @('备战阶段', '出战', '商店')
        target_evidence = @{
            control_id = 'prep_startup_guide_2'
            snapshot_id = $q.snapshot_id
            bounds = @(1650, 39, 1727, 94)
        }
        reason = '本 epoch 奖励已全场核空，打开原生第二创业指南入口'
    })
}
```

坐标与范围是原 1920 原生入口合同；现场条件变化由原消费者拒绝，不通过改 ROI 强行套用。查看原 navigation 记录及原输入收据，`expected_title_observed` 只证明已打开，不完成指南阶段。

### 四、普通当前请求生成并提交一次滚动

打开后等待当前 `unknown_page` 请求，清单仍为 `startup_guide`，没有 manual intent。ROOT 从本请求原图与 OCR 选当前章节和右侧列表内一条完整唯一文字。计数若已裁切，不沿用旧 0/2；用另一条完整任务描述。

```powershell
& ./handoff/2026-10-08/New-TaskScrollReply.ps1 `
    -Python $py `
    -RequestFile $currentRequestFile `
    -ChapterText $currentChapterText `
    -TargetText $currentCompleteListText `
    -Delta -1200 `
    -OutputFile $newScrollReplyFile
if ($LASTEXITCODE -ne 0) { throw 'Plan construction refused; no submission.' }

& $py -B -X utf8 tools/currency_wars_runner.py decide @cwAuth --reply-file $newScrollReplyFile
```

这个构造器不发输入。missing text、point-outsideROI、列表外文字、不合法滚轮量会在生成或公开提交端拒绝；不能把坏 payload 留到 Worker 才停整局。函数生成完整原 source、snapshot、capture、frame、chapter 和真实 list_bounds，点取实际文字框中心。普通 `decide` 在 Worker 当前阶段绑定后复用同一受检输入路径。

此例为推进选择一笔有界 `-1200`，其幅度的实机验收尚由 ROOT 执行；若本次只验原生已观察的幅度，改成 `-120`。不要把循环十次 `-120` 或多个动作塞入一份计划。第一次后帧不足以证明时先看原 task-scroll 记录与原输入收据，区分交付和效果；待原交付已核且确有进一步滚动意图，才从当前新请求生成下一笔，而不是重试旧 ID。

持久记录 `task-scroll-<request_id>.json` 的 `input_request_id` 才是游戏滚轮输入 ID。`verified/shift_y` 证明位移，`verification_reads=0` 表示使用已有回帧；pending 不自动宣告失败，更不自动重发。当前原生 page 继续是 unknown。

技术位移后验 pending 本身不要求再滚一次。若原输入交付已核、ROOT 已从当前完整鲜帧实际看清末尾并完成必要业务检查，可以按下一节提交普通无输入业务复核，同时让原 task-scroll pending 原样保留。若当前还看不到末尾，就保留未知并针对实际剩余内容规划；不能用技术记录的状态代替实际领取事实。

如果现场已经合法处于 manual checkpoint，构造器保持同样调用；提交改用原 `manual-step`：

```powershell
& $py -B -X utf8 tools/currency_wars_runner.py manual-step @cwAuth `
    --manual-id $manualId --checkpoint-id $checkpointId `
    --operation reviewed_plan --reply-file $newScrollReplyFile --request-id $fixedManualStepId
```

该分支须已有真实人工阶段和 broker 交接；本次推荐新恢复路径无需为了滚动进入此分支。不要往 manual-step 的 reviewed_plan 塞 `context_update`，原接口仍拒绝。

### 五、完成本次检查并继续主局

ROOT 实际核到列表末尾、当前可领的已完成奖励已处理且按原收据/后帧确认后，再在当前 ordinary 请求提交第三节 wrapper，`$value` 为：

```powershell
$value = @{
    phase = 'startup_guide'
    stage = $q.battle_stage
    reviewer = 'supervising_agent'
    completed = $true
    findings = $freshGuideFindings
    entry_index = 2
    rewards_claimed = $true
    goals = @($freshGuideGoals)
}
$reply = New-CwPreparationReply -Request $q -Value $value
```

`$freshGuideFindings/$freshGuideGoals` 是本次同局、同 epoch 的实际检查数据，保留各读帧和动作记录供独立核验；不从旧 run 复制进度与领取布尔再换 proof。对当前没确认的目标字段保留未知。已知未达成的目标可保留 `condition_met=false`，不需要在 1-1 先完成特权赋予卡 2 次使用才进入经济。

此时 `completed=true` 指本次检查完成；`rewards_claimed=true` 只指已达成而可领的奖励确已核空。当前仍没看完末尾，或出现未决领取效果，就不能提交这份完成值。

普通指南复核接受后，Worker 保留本 epoch 的 startup_guide 结果，清掉 rewards，要求回场再扫可能的新掉落。对下一份当前 Guide 请求通过普通 `decide` 提交第一节的单 Escape 形状，但取此次新的 request/snapshot/epoch；它不是 business_recovery 请求，不添加任何恢复标记。

关页后从实际 full preparation 新帧按第三节再次独立复核 rewards。导航不清掉已经完成的指南，所以这次奖励接受后下一阶段应为 `inventory_cleanup`，随后才是 `economy`。核当前状态与 `preparation_phase_verified` 记录，不能把入队成功当作已经解锁。

后续库存、经济计划、D/F、购买、上场、装备、出战审批与整局结算仍走既有消费者。此处交付的是从当前阻断回到主业务的可验收入口，不预报库存/经济已完成或整局已经提速。

### 等待与租期

沿用原 7200 秒 Worker 上限、600 秒 broker 空闲上限、各请求原期限。不要靠延长设置或新造请求续旧 proof。普通 waiting_decision 使用同 Worker 既有每 90 秒的有界被动观察维护；没有另一个普通 `runner inspect` 命令。只有现场已实际处于 manual 时，才使用原 `manual-step --operation inspect` 做所属 Worker 的只读检查，不为维护租期新增一次接管。仅查看 status 或旧图片不等于发生新的 broker 观察；原请求到期也不会因此延长。若已经正常退出，重新走 start/当前业务复核，不能从旧 runtime 抽 token、checkpoint 或节点拼接恢复。

## 验收入口和测试替身边界

Windows 最小入口是新聚合消费者脚本。它运行精确选择的新方法，不扫源码冒充测试，也不重跑旧导航/旧 manual-flow 套：

```powershell
& $py -B -X utf8 tools/replay_currency_wars_native_scroll.py `
    --output $newWindowsReport `
    --require-runtime-resources
if ($LASTEXITCODE -ne 0) { throw 'Current consumer/resource verification failed.' }
```

ROOT 实际安装树应保有原 64 资源/provider，并用该开关确认完整绑定。公开 Linux checkout 缺少实际 reader resources；本地报告明确 `runtime_resource_binding_complete=false`，不能借前次 Windows 的 64 资源报告声称本候选已通过部署。

最终精确方法列表、子例数量、时间、源码/素材 SHA 和加载闭包见 `linux-acceptance.json`。测试报告以测试前后真实字节为准，不能只凭测试时 HEAD 的父提交认证未提交改动。新增普通出口检查须真实经过 rewards 无输入 review、当前 phase 构造、normal decide/Worker/Entry、指南 review、Escape 与新 rewards，再到 inventory；不是预置一份 pending checkpoint 或把 completed 字典塞进 Worker。

原生配对正例保留原像素。位移、覆盖、变字、错来源、当前 phase 失效和新接管负例分别验证零输入拒绝或已交付但效果保持未知。对 `-1200` 的协议消费者正例复用已声明的原生 `-120` 后帧，只证明单笔范围/消费者合同，不能作为真实大幅滚动效果证据。

明确替身包括 Windows 进程/窗口探测、broker 传输及原图外围缺失区域；备战返回 HUD 为声明的协议图像替身；新恢复使用真实 Worker constructor、业务续接初始化和原 Entry/业务消费者，但没有启动 Windows 进程、UAC 或真实游戏输入。离线 OCR 与负例改图分别标明，不称作原始 ROOT 观察。这里的耗时不是一局游戏的耗时。

生产范围限两个现有 Python 文件和原计划构造器的小改动。GUI、runtime manifest、原 controller、broker 的限制、关键经济守卫、人工阶段管理器及历史 unknown 未改。ROOT 下一门仍是本候选独立审查、上述 Windows 入口、原资源/provider 与安装/check-launch、同局实机恢复及单笔滚动。

## 非关键核验不应永久阻塞主局

我同意把通用技术问题留到赛后，当前先处理具体阻断。此次普通阶段接入就是为了避免一次滚动迫使整套接管与重复复核，并没有为 1-1 扩建另一套控制框架。

现有接口能如实保存人工 `completed=false/outcome=unknown` 的未核结果，但这只保存事实，不能合法越过 startup_guide 去经济。直接写 completed 或 rewards_claimed 来“暂存以后补”会伪造状态，本候选没有采用。

建议赛后评估明确的“本次非关键指南检查延期”处置：把任务条件、奖励领取状态和本次检查处置分开；只对可延期的指南核验允许监督者登记原因、原 match/stage、原 source/request、未核项目和原交付 ID。到下一安全备战窗口或整局结算后重新提醒；领取前必须取得当前新 proof，历史 pending/unknown 原样保留。经济余额、库存容量、关键战略选项、上场与出战门不能借这个处置延期。

是否按这种明确处置允许主流程继续，应在规则与消费者共同支持后评估，不能仅加一个 bypass 布尔。本次不实现该赛后能力，也不把它写成当前合法快捷入口。眼下出口是先用受检单笔滚动完成本次末尾核验，再在同一普通 epoch 交还主业务。

## 采用的通用实践

借鉴范围限现有骨架缺的部分：局部窗口中重新定位候选、把容器范围写入手势合同、将输入交付与实际滚动后验分开。没有引入 Appium、Playwright 或额外控制器。

- OpenCV 官方模板匹配文档：局部位置匹配及候选比较，https://docs.opencv.org/4.x/d4/dc6/tutorial_py_template_matching.html 。
- Appium 官方 GitHub 的 scrollGesture：显式元素或范围约束与滚动反馈，https://github.com/appium/appium-uiautomator2-driver/blob/master/docs/android-mobile-gestures.md#mobile-scrollgesture 。
- Playwright 官方 mouse.wheel 文档：调用返回不保证滚动已结束，https://playwright.dev/docs/api/class-mouse#mouse-wheel 。

本次的 2px/8px、两张任务卡、原生容器与有界位移是依据现有代码和本案原生证据选择的工程合同，不是这些文档给出的通用标准；其他分辨率、皮肤或未知布局未获本案实证支持。
