# 原生指南滚动与续接候选

先读 NATIVE_SCROLL_RECOVERY.html。

- 唯一父：d0056bdc03bc967d5138781f29518a970b7ceab9
- 本地候选：b83d3ff6e57d09837b75ee9511a6beced9cd58ba
- 只提供下载交付；没有声称推送或部署。
- 生产修改：runner、visual_guards；原 PS1 构造器加入真实 list_bounds，消费者和原生证据随包。
- 精确测试：10 方法、39 子例，0 failure/error/skip，32.5159850s。
- Linux 的实际运行资源缺失仍如实记录；ROOT 使用 --require-runtime-resources 核 Windows 实际安装树。

## 隔离应用

在 ROOT 自己创建的干净隔离 worktree 中，先确认 HEAD 恰为唯一父、无其他待合修改。新 worktree 的首次 checkout 也使用进程级换行配置，不改全局 Git；$cwCandidateDir 必须是 ROOT 新选的不存在目录：

```powershell
git -c core.autocrlf=false -c core.eol=lf worktree add --detach $cwCandidateDir d0056bdc03bc967d5138781f29518a970b7ceab9
Set-Location -LiteralPath $cwCandidateDir
git -c core.autocrlf=false -c core.eol=lf apply --check --index --binary --whitespace=error currency-wars-native-scroll-d0056bd.patch
git -c core.autocrlf=false -c core.eol=lf apply --index --binary --whitespace=error currency-wars-native-scroll-d0056bd.patch
```

补丁路径应指向本包的实际绝对路径，或将补丁放在上述隔离目录；不要在正在运行的安装树试应用。应用后与 manifest.json 的 changed_files 及 source_sha256/artifact_sha256 逐字节核对。apply-check.json 记录本地在同父的真实检查与应用，不替代 Windows。

## 最小 Windows 入口

```powershell
& $py -B -X utf8 tools/replay_currency_wars_native_scroll.py --output $newWindowsReport --require-runtime-resources
```

继续按 ROOT 原独立复核、实际资源/provider、安装和 check-launch 门，再逐段执行 HTML 中当前 fresh public API。新普通滚动出口不要求新的 takeover/resume。历史两笔 pending、所有 unknown 和当前末尾未知保持原事实。

SHA256SUMS 包含本包各文件（不含自身），ZIP 自身摘要单独随交付提供。
