"""Owned scratch directories; no import side effects or general session cleanup."""
from __future__ import annotations

import argparse
import contextlib
import itertools
import json
import os
import re
import shutil
import stat
import sys
import tempfile
import time
import uuid
from pathlib import Path

MARKER = ".agent-workflow-owner.json"
TOOL = "codex-agent-workflow"
MAX_MARKER_BYTES = 4096
MAX_TREE_ENTRIES = 20000
MAX_TREE_BYTES = 512 * 1024 * 1024
MAX_CHILDREN = 32
DEFAULT_MIN_AGE_SECONDS = 24 * 60 * 60


class ArtifactError(ValueError):
    """Cleanup could not establish ownership or a safe deletion target."""


def default_root():
    return Path(tempfile.gettempdir()) / TOOL


def _absolute(value):
    path = Path(value).expanduser()
    if not path.is_absolute():
        raise ArtifactError("Artifact paths must be absolute.")
    return Path(os.path.abspath(path))


def _no_link(path):
    try:
        info = path.lstat()
    except FileNotFoundError:
        return
    if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
        raise ArtifactError("Artifact paths must not contain links or junctions.")


def _ancestors(path):
    for part in (path, *path.parents):
        _no_link(part)


def _target(path, root):
    root, path = _absolute(root), _absolute(path)
    _ancestors(root)
    _ancestors(path)
    if root == Path(root.anchor) or path.parent != root or path.resolve().parent != root.resolve():
        raise ArtifactError("Artifact target must be a direct child of its declared root.")
    if not path.is_dir():
        raise ArtifactError("Artifact directory is missing.")
    return path, root


def process_identity(pid):
    """Return (active|dead|unknown, creation identity), using read-only queries.

    In particular, os.kill(pid, 0) is never used: on Windows it can terminate
    a process. Permission failures and unsupported platforms stay unknown.
    """
    if type(pid) is not int or not 0 < pid <= 0xFFFFFFFF:
        return "unknown", None
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetProcessTimes.argtypes = (wintypes.HANDLE, *(ctypes.POINTER(wintypes.FILETIME),) * 4)
        kernel.GetProcessTimes.restype = wintypes.BOOL
        kernel.GetExitCodeProcess.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
        kernel.GetExitCodeProcess.restype = wintypes.BOOL
        kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
        kernel.CloseHandle.restype = wintypes.BOOL
        handle = kernel.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not handle:
            return ("dead", None) if ctypes.get_last_error() == 87 else ("unknown", None)
        try:
            created, exited, kernel_time, user_time = (wintypes.FILETIME() for _ in range(4))
            code = wintypes.DWORD()
            if not kernel.GetProcessTimes(handle, created, exited, kernel_time, user_time):
                return "unknown", None
            identity = "windows:" + str((created.dwHighDateTime << 32) | created.dwLowDateTime)
            if not kernel.GetExitCodeProcess(handle, code):
                return "unknown", None
            return ("active" if code.value == 259 else "dead"), identity
        finally:
            kernel.CloseHandle(handle)
    if sys.platform.startswith("linux"):
        proc = Path("/proc")
        if not proc.is_dir():
            return "unknown", None
        try:
            text = (proc / str(pid) / "stat").read_text(encoding="ascii")
            # The process name in parentheses can itself contain spaces or ')'.
            fields = text[text.rindex(")") + 2:].split()
            started = fields[19]  # /proc/PID/stat field 22, counted after comm
            boot = (proc / "sys/kernel/random/boot_id").read_text(encoding="ascii").strip()
            if not started.isdecimal() or not re.fullmatch(r"[0-9a-f-]{36}", boot):
                return "unknown", None
            return "active", "linux:" + boot + ":" + started
        except FileNotFoundError:
            # /proc may hide another user's live PID. pidfd_open distinguishes
            # ESRCH without signalling a process; absence alone is insufficient.
            if hasattr(os, "pidfd_open"):
                try:
                    descriptor = os.pidfd_open(pid, 0)
                except ProcessLookupError:
                    return "dead", None
                except OSError:
                    return "unknown", None
                else:
                    os.close(descriptor)
            return "unknown", None
        except (OSError, ValueError, IndexError, UnicodeError):
            return "unknown", None
    return "unknown", None


def _owner_pids():
    """Accept the real parent, including one read-only verified venv redirector."""
    allowed = {os.getpid(), os.getppid()}
    if os.name != "nt" or sys.executable == getattr(sys, "_base_executable", sys.executable):
        return allowed
    import ctypes
    from ctypes import wintypes

    class BasicInfo(ctypes.Structure):
        _fields_ = [("exit_status", wintypes.LONG), ("peb", ctypes.c_void_p),
                    ("affinity", ctypes.c_size_t), ("priority", wintypes.LONG),
                    ("pid", ctypes.c_size_t), ("parent", ctypes.c_size_t)]

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    native = ctypes.WinDLL("ntdll")
    kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.QueryFullProcessImageNameW.argtypes = (wintypes.HANDLE, wintypes.DWORD,
                                                wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD))
    kernel.QueryFullProcessImageNameW.restype = wintypes.BOOL
    kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    native.NtQueryInformationProcess.argtypes = (wintypes.HANDLE, wintypes.ULONG, ctypes.c_void_p,
                                                 wintypes.ULONG, ctypes.POINTER(wintypes.ULONG))
    native.NtQueryInformationProcess.restype = wintypes.LONG
    handle = kernel.OpenProcess(0x1000, False, os.getppid())
    if not handle:
        return allowed
    try:
        buffer = ctypes.create_unicode_buffer(32768)
        length = wintypes.DWORD(len(buffer))
        info, size = BasicInfo(), wintypes.ULONG()
        if (kernel.QueryFullProcessImageNameW(handle, 0, buffer, length)
                and Path(buffer.value) == Path(sys.executable)
                and native.NtQueryInformationProcess(handle, 0, ctypes.byref(info), ctypes.sizeof(info), size) >= 0
                and 0 < info.parent <= 0xFFFFFFFF):
            allowed.add(info.parent)
    finally:
        kernel.CloseHandle(handle)
    return allowed


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ArtifactError("Artifact marker contains duplicate fields.")
        result[key] = value
    return result


def _valid_identity(value):
    return value is None or (isinstance(value, str) and re.fullmatch(
        r"windows:[1-9][0-9]{0,19}|linux:[0-9a-f-]{36}:[0-9]{1,20}", value) is not None)


def _child_records(value):
    if not isinstance(value, list) or len(value) > MAX_CHILDREN:
        raise ArtifactError("Artifact child inventory exceeds its bound.")
    result, seen = [], set()
    for entry in value:
        if not isinstance(entry, dict):
            raise ArtifactError("Artifact child identity is invalid.")
        pid, identity = entry.get("pid"), entry.get("process_identity", entry.get("identity"))
        if type(pid) is not int or not 0 < pid <= 0xFFFFFFFF or not _valid_identity(identity):
            raise ArtifactError("Artifact child identity is invalid.")
        key = (pid, identity)
        if key not in seen:
            result.append({"pid": pid, "process_identity": identity})
            seen.add(key)
    return result


def read_marker(path, *, root=None, purpose=None):
    """Read bounded provenance only after checking absolute containment."""
    path = _absolute(path)
    path, root = _target(path, default_root() if root is None else root)
    marker = path / MARKER
    _no_link(marker)
    info = marker.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_MARKER_BYTES:
        raise ArtifactError("Artifact marker is missing or too large.")
    try:
        with marker.open("rb") as stream:
            data = stream.read(MAX_MARKER_BYTES + 1)
        value = json.loads(data.decode("utf-8"), object_pairs_hook=_object)
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise ArtifactError("Artifact marker is invalid.") from exc
    if (not isinstance(value, dict) or type(value.get("schema")) is not int
            or value["schema"] != 1 or value.get("tool") != TOOL):
        raise ArtifactError("Artifact marker belongs to another tool.")
    if (not isinstance(value.get("run_id"), str) or not re.fullmatch(r"[0-9a-f]{32}", value["run_id"])
            or value.get("root") != str(root) or value.get("path") != str(path)
            or not isinstance(value.get("purpose"), str) or not re.fullmatch(r"[a-z][a-z0-9-]{0,63}", value["purpose"])
            or (purpose is not None and value["purpose"] != purpose)
            or type(value.get("pid")) is not int or not 0 < value["pid"] <= 0xFFFFFFFF
            or type(value.get("created_at")) not in (int, float)
            or not 0 < value["created_at"] <= 10**12
            or not _valid_identity(value.get("process_identity"))
            or type(value.get("children_incomplete", False)) is not bool):
        raise ArtifactError("Artifact provenance does not match its directory.")
    _child_records(value.get("protected_children", []))
    hint = value.get("session_hint")
    if hint is not None and (not isinstance(hint, dict) or hint.get("source") != "environment-declared"
            or (hint.get("id") is not None and (not isinstance(hint["id"], str)
                or not 0 < len(hint["id"]) <= 128 or any(ord(char) < 33 for char in hint["id"])))):
        raise ArtifactError("Artifact session hint is invalid.")
    return value


def _session_completed(value, session_status):
    """A declared environment hint only vetoes cleanup until observed complete."""
    hint = value.get("session_hint")
    if hint is None:
        return True
    if not isinstance(hint.get("id"), str) or session_status is None:
        return False
    try:
        status = session_status(hint["id"])
        return type(status) is str and status == "completed"
    except Exception:
        return False


def _child_dead(entry):
    identity = entry["process_identity"]
    if identity is None:
        return False
    state, actual = process_identity(entry["pid"])
    prefix = "windows:" if os.name == "nt" else "linux:" if sys.platform.startswith("linux") else None
    return (prefix is not None and identity.startswith(prefix)
            and (state == "dead" or (state == "active" and isinstance(actual, str)
                                     and _valid_identity(actual) and actual.startswith(prefix) and actual != identity)))


def _live_owner(value, expected_run_id=None):
    state, identity = process_identity(value["pid"])
    return (value["pid"] in _owner_pids() and state == "active" and identity is not None
            and identity == value["process_identity"]) or (
                expected_run_id is not None and value["pid"] == os.getpid()
                and state == "unknown" and value["process_identity"] is None)


def protect_children(path, children, *, root=None, complete=None, expected_run_id=None):
    """Merge native child leases; only the live owner may declare final inventory."""
    root = default_root() if root is None else root
    value = read_marker(path, root=root)
    if (expected_run_id is not None and value["run_id"] != expected_run_id) or not _live_owner(value, expected_run_id):
        raise ArtifactError("Only the verified live artifact owner may register children.")
    incoming = _child_records(children)
    existing = _child_records(value.get("protected_children", []))
    remaining = {(entry["pid"], entry["process_identity"]): entry
                 for entry in existing + incoming if not _child_dead(entry)}
    merged = _child_records(list(remaining.values()))
    if complete is True and merged:
        raise ArtifactError("Artifact children are active or cannot be verified dead.")
    updated = dict(value, protected_children=merged)
    if complete is not None:
        updated["children_incomplete"] = not complete
    data = (json.dumps(updated, sort_keys=True) + "\n").encode("utf-8")
    if len(data) > MAX_MARKER_BYTES:
        raise ArtifactError("Artifact child inventory exceeds its marker size limit.")
    path, root = _target(path, root)
    descriptor, temporary = tempfile.mkstemp(prefix=".artifact-marker-", dir=path)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        if read_marker(path, root=root) != value:
            raise ArtifactError("Artifact provenance changed while registering children.")
        os.replace(temporary, path / MARKER)
    finally:
        Path(temporary).unlink(missing_ok=True)
    return updated


def _tree_size(path):
    count, total = 0, 0
    folders = [path]
    while folders:
        folder = folders.pop()
        _no_link(folder)
        with os.scandir(folder) as entries:
            for child in entries:
                count += 1
                if count > MAX_TREE_ENTRIES:
                    raise ArtifactError("Artifact cleanup exceeds its bounded tree limit.")
                entry = folder / child.name
                _no_link(entry)
                info = entry.lstat()
                if stat.S_ISDIR(info.st_mode):
                    folders.append(entry)
                elif stat.S_ISREG(info.st_mode):
                    # A hard link could refer to a retained file outside the root.
                    if info.st_nlink != 1:
                        raise ArtifactError("Artifact directory contains a hard link.")
                    total += info.st_size
                    if total > MAX_TREE_BYTES:
                        raise ArtifactError("Artifact cleanup exceeds its bounded tree limit.")
                else:
                    raise ArtifactError("Artifact directory contains a special file.")
    return total


def _remove(path, root, value):
    path, root = _target(path, root)
    if read_marker(path, root=root) != value:
        raise ArtifactError("Artifact provenance changed before cleanup.")
    size = _tree_size(path)
    # Recheck the deletion root and marker after inspecting the bounded tree.
    _target(path, root)
    if read_marker(path, root=root) != value:
        raise ArtifactError("Artifact provenance changed before cleanup.")
    # Keep provenance while deleting payloads. Windows can reject a locked
    # SQLite/browser file after rmtree has already removed the root marker.
    # Such a partial run must remain attributable and retryable.
    marker = path / MARKER
    marker_bytes = marker.read_bytes()
    directory_identity = (path.stat().st_dev, path.stat().st_ino)
    for child in path.iterdir():
        if child.name == MARKER:
            continue
        _target(path, root)
        if read_marker(path, root=root) != value:
            raise ArtifactError("Artifact provenance changed during cleanup.")
        _no_link(child)
        info = child.lstat()
        if stat.S_ISDIR(info.st_mode):
            shutil.rmtree(child)
        elif stat.S_ISREG(info.st_mode) and info.st_nlink == 1:
            child.unlink()
        else:
            raise ArtifactError("Artifact payload changed during cleanup.")
    if read_marker(path, root=root) != value:
        raise ArtifactError("Artifact provenance changed before final cleanup.")
    marker.unlink()
    try:
        path.rmdir()
    except BaseException as exc:
        # Restore only the original marker in the same verified directory;
        # never replace an existing marker or adopt an unknown old run.
        try:
            _target(path, root)
            info = path.stat()
            if (info.st_dev, info.st_ino) == directory_identity:
                with marker.open("xb") as stream:
                    stream.write(marker_bytes)
        except (OSError, ArtifactError) as restore_error:
            if hasattr(exc, "add_note"):
                exc.add_note("Original artifact marker could not be restored: " + str(restore_error))
        raise
    return size


def cleanup_owned_directory(path, *, root=None, purpose=None, expected_run_id=None, require_dead=False):
    """Delete a verified owned directory; explicit close accepts its live owner.

    A CLI child can close a run owned by its actual parent. Other live owners,
    PID reuse, unknown identities, and unknown ownership always remain intact.
    """
    root = default_root() if root is None else root
    value = read_marker(path, root=root, purpose=purpose)
    if expected_run_id is not None and value["run_id"] != expected_run_id:
        raise ArtifactError("Artifact run identity changed.")
    if value.get("children_incomplete", False) or any(not _child_dead(entry) for entry in
                                                     _child_records(value.get("protected_children", []))):
        raise ArtifactError("Artifact child inventory is incomplete, active, or unknown.")
    state, identity = process_identity(value["pid"])
    native_prefix = "windows:" if os.name == "nt" else "linux:" if sys.platform.startswith("linux") else None
    proven_dead = (state == "dead" and native_prefix is not None
                   and isinstance(value["process_identity"], str) and value["process_identity"].startswith(native_prefix))
    if not (proven_dead or (not require_dead and _live_owner(value, expected_run_id))):
        raise ArtifactError("Artifact owner is active elsewhere or cannot be verified.")
    return _remove(path, root, value)


class OwnedDirectory:
    def __init__(self, path, root, value):
        self.path, self.root, self._value = path, root, value

    def close(self):
        try:
            self.path.lstat()
        except FileNotFoundError:
            return 0
        if read_marker(self.path, root=self.root) != self._value:
            raise ArtifactError("Artifact provenance changed since creation.")
        return cleanup_owned_directory(self.path, root=self.root, purpose=self._value["purpose"],
                                       expected_run_id=self._value["run_id"])

    def protect_children(self, children, *, complete=None):
        self._value = protect_children(self.path, children, root=self.root, complete=complete,
                                       expected_run_id=self._value["run_id"])

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


def _marker_value(path, root, purpose, owner_pid=None):
    if not isinstance(purpose, str) or not re.fullmatch(r"[a-z][a-z0-9-]{0,63}", purpose):
        raise ArtifactError("Artifact purpose is invalid.")
    pid = os.getpid() if owner_pid is None else owner_pid
    if type(pid) is not int or pid not in _owner_pids():
        raise ArtifactError("Artifact owner must be the current process or its actual parent.")
    state, identity = process_identity(pid)
    if state == "dead" or (pid != os.getpid() and (state != "active" or identity is None)):
        raise ArtifactError("Artifact process creation identity cannot be verified.")
    value = {"schema": 1, "tool": TOOL, "run_id": uuid.uuid4().hex, "purpose": purpose,
            "pid": pid, "process_identity": identity, "created_at": time.time(),
            "root": str(root), "path": str(path), "protected_children": [], "children_incomplete": False}
    session = os.environ.get("CODEX_THREAD_ID")
    if session:
        known_id = session if len(session) <= 128 and all(ord(char) >= 33 for char in session) else None
        value["session_hint"] = {"id": known_id, "source": "environment-declared"}
    return value


def mark_owned_directory(path, purpose, *, root):
    """Mark a caller's freshly promoted successful backup, never legacy history."""
    path, root = _target(path, root)
    value = _marker_value(path, root, purpose)
    _tree_size(path)
    with (path / MARKER).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, sort_keys=True)
        stream.write("\n")
    return OwnedDirectory(path, root, value)


def create_owned_directory(purpose="run", *, root=None, prefix=None, owner_pid=None):
    prefix = purpose + "-" if prefix is None and isinstance(purpose, str) else prefix
    if not isinstance(prefix, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,95}", prefix):
        raise ArtifactError("Artifact directory prefix is invalid.")
    sweep_default = root is None
    root = _absolute(default_root() if root is None else root)
    value = _marker_value(None, root, purpose, owner_pid)
    _ancestors(root)
    if root == Path(root.anchor):
        raise ArtifactError("Artifact root must be a dedicated directory.")
    if sweep_default:
        sweep_stale(root=root)
    root.mkdir(parents=True, exist_ok=True)
    _ancestors(root)
    path = Path(tempfile.mkdtemp(prefix=prefix, dir=root))
    value["path"] = str(path)
    try:
        _target(path, root)
        with (path / MARKER).open("x", encoding="utf-8") as stream:
            json.dump(value, stream, sort_keys=True)
            stream.write("\n")
    except BaseException:
        # A just-created empty directory is ours, even before marker publication.
        _target(path, root)
        (path / MARKER).unlink(missing_ok=True)
        path.rmdir()
        raise
    return OwnedDirectory(path, root, value)


@contextlib.contextmanager
def scratch_directory(purpose="run", *, root=None):
    """Yield a Path in the OS temp namespace and actually clean it in finally."""
    if root is not None:
        sweep_stale(root=root, purpose=purpose)
    owned = create_owned_directory(purpose, root=root)
    try:
        yield owned.path
    finally:
        owned.close()


def sweep_stale(*, root=None, purpose=None, max_entries=64, max_deletions=8,
                min_age_seconds=DEFAULT_MIN_AGE_SECONDS, protected=(), session_status=None):
    """Sweep proven-dead runs; associated chats need observed completed status.

    session_status(id) must return active/completed/unknown from a caller's
    read-only observation. Missing or failed observation preserves the run.
    """
    if (type(max_entries) is not int or not 0 <= max_entries <= 1024
            or type(max_deletions) is not int or not 0 <= max_deletions <= max_entries
            or type(min_age_seconds) not in (int, float) or not 0 <= min_age_seconds <= 10**12):
        raise ArtifactError("Artifact sweep limits are invalid.")
    root = _absolute(default_root() if root is None else root)
    _ancestors(root)
    report = {"scanned": 0, "removed": [], "bytes": 0}
    if not root.exists():
        return report
    keep = {_absolute(path) for path in protected}
    now = time.time()
    with os.scandir(root) as entries:
        for entry in itertools.islice(entries, max_entries):
            report["scanned"] += 1
            if len(report["removed"]) >= max_deletions:
                break
            path = root / entry.name
            if path in keep:
                continue
            try:
                value = read_marker(path, root=root, purpose=purpose)
                if now - value["created_at"] < min_age_seconds or not _session_completed(value, session_status):
                    continue
                size = cleanup_owned_directory(path, root=root, purpose=purpose,
                                               expected_run_id=value["run_id"], require_dead=True)
            except (ArtifactError, OSError):
                continue
            report["removed"].append(str(path))
            report["bytes"] += size
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    create = sub.add_parser("create")
    create.add_argument("--purpose", default="run")
    create.add_argument("--owner-pid", type=int)
    create.add_argument("--root")
    cleanup = sub.add_parser("cleanup")
    cleanup.add_argument("--path", required=True)
    cleanup.add_argument("--root")
    protect = sub.add_parser("protect")
    protect.add_argument("--path", required=True)
    protect.add_argument("--root")
    protect.add_argument("--children", required=True)
    finality = protect.add_mutually_exclusive_group()
    finality.add_argument("--incomplete", action="store_true")
    finality.add_argument("--complete", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.command == "create":
            if args.root is not None:
                sweep_stale(root=args.root, purpose=args.purpose)
            print(create_owned_directory(args.purpose, root=args.root, owner_pid=args.owner_pid).path)
        elif args.command == "protect":
            if len(args.children) > MAX_MARKER_BYTES:
                raise ArtifactError("Artifact child inventory exceeds its input size limit.")
            try:
                children = json.loads(args.children, object_pairs_hook=_object)
            except (ValueError, RecursionError) as exc:
                raise ArtifactError("Artifact child inventory is invalid JSON.") from exc
            complete = True if args.complete else False if args.incomplete else None
            protect_children(args.path, children, root=args.root, complete=complete)
        else:
            cleanup_owned_directory(args.path, root=args.root)
    except (ArtifactError, OSError) as exc:
        print("Artifact operation failed: " + str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
