# Currency Wars Automation

《崩坏：星穹铁道》货币战争的 Windows 本地助手：Rust/Tauri 界面、Python 执行器、OCR，以及带暂停、接管和停止保护的单窗口输入控制。

**当前发布是源码版。战略决策仍需要 Codex 在本机监督并回答请求，没有配置独立 AI 服务，也没有验证另一台电脑可无人值守完成整局。** 界面名称中的“一条龙”是目标，不是当前自动通关保证。

## MCP 接口（可选）

本机已接入 Codex 的 `currency-wars` stdio MCP，提供状态读取和原执行器的受检计划提交。安装、会话绑定与当前限制见 [MCP 说明](mcp/README.md)，本机证据见 [当前验证记录](docs/CURRENT_VERIFICATION.json)。这是连接层；独立决策求解器和无人值守整局尚未交付。其他电脑需单独安装及注册。

## 在另一台电脑安装

要自动同步，请安装 Git 并运行 `git clone https://github.com/gkcc/Currency-Wars-Automation.git`。也可下载 ZIP 解压，但 ZIP 安装只会提示改用 Git clone，不会替换你的目录。路径可自行选择，不要求特定盘符，也不要求安装 Codex Agent Workflow 技能。

准备 Windows 10/11 x64、Python 3.11–3.13、Microsoft Edge WebView2，以及用于编译界面的 Rust MSVC 工具链和 Visual Studio C++ 构建工具。在项目目录的 PowerShell 中运行：

```powershell
.\Setup.ps1 -BuildGui
.\Start.ps1
```

安装会下载 Python/Rust 依赖，创建项目独立 `.venv`，并构建 `gui/bin/currency-wars-gui.exe`。编译缓存保存在 `gui/target`。安装本身不打开游戏，不运行游戏输入。已有匹配的本机编译结果时可使用 `Setup.ps1`。

推荐使用 `Start.ps1`；它通过项目解释器传入实际项目路径、本次会话身份和所属临时运行目录。源码编译后的 EXE 也能找到同项目的 `.venv`。没有提供已验证的跨电脑二进制安装包。

## 换机接续这次修改

已有 Git clone 时，先退出助手和控制器，在仓库目录运行：

```powershell
git pull --ff-only origin main
.\Setup.ps1 -BuildGui
.\Start.ps1 -ChatId <新电脑实际Codex会话ID>
```

没有 clone 时先运行 `git clone https://github.com/gkcc/Currency-Wars-Automation.git`，再进入目录执行安装。新电脑会重新构建界面；本机 `.venv`、二进制、就绪批准、会话凭据和控制器运行目录不迁移。浮窗与带教/全托管设置、聊天窗口绑定也需在新电脑重新设置。

## 自动检测和同步更新

正常启动时会自动检查规范仓库 `gkcc/Currency-Wars-Automation` 的 `main`，并为干净的 Git clone 执行安全的快进同步。它核对原始和 Git 实际解析的远端地址，拒绝重定向到其他仓库；只同步源码，不切换分支，不重置或清理本地文件。

本地有未提交修改、历史分叉、其他分支，或 GUI、执行器、broker 的活动/退出状态未知时，跳过同步。启动注册和更新共享互斥保护，避免控制器启动期间改写源码。远端改动若涉及 `docs`、运行目录、截图、`.venv`、商店模板、编译缓存或 `gui/bin`，也会拒绝同步。已有本机数据和修改保留原样。

网络查询有超时限制；更新失败会显示在启动输出和界面的更新提示中，已有有效本机版本仍可打开。Python 依赖变化需要重新运行 `Setup.ps1`；Rust 或界面资源变化需要 `Setup.ps1 -BuildGui`。安装/构建指纹必须来自本机实际操作，过期二进制会阻止启动，更新器不会静默运行旧 EXE，也不会自动重装系统工具链、重开界面、启动游戏或恢复游戏控制。

手动检查或同步：

界面右上方有“检查更新”按钮。它在后台查询远端版本，显示当前/远端提交和同步阻因；运行中或本地有修改时也可以查询。按钮只检查版本，源码同步仍遵循上述保护。

```powershell
.\Update.ps1 -CheckOnly
.\Update.ps1
```

ZIP 用户请另建 Git clone，再按需迁移自己的本机数据；更新器不会接管或覆盖 ZIP 目录。

## 本机输入权限组件

本机游戏以管理员权限运行时，普通执行器使用一次安装的固定输入组件，策略代码和界面仍以普通权限运行。修改策略、暂停或重启执行器不再触发 Python 管理员授权。固定组件只对已批准的游戏映像和本次所属窗口提供现有输入协议。

当前本机部署使用 CPython 3.12，将私有解释器、依赖和固定控制层封装后安装到 `D:\CurrencyWarsInputBridge`。普通用户仅能读取和运行该组件；计划任务使用当前交互用户，无开机触发器，不保存密码。安装前需要独立复核包和源码，并生成 `docs/INPUT_BRIDGE_PACKAGE.json`；然后运行 `Install-InputBridge.ps1`，通过这一次 Windows 管理员安装提示。安装完成后还须验证实际权限和无输入重启周期，才能启用游戏控制。

若组件缺失、安装文件改变或仍有未核实的旧控制器，启动会给出原因，不会反复弹授权。修改固定的高权限控制层需要重新进行正式安装；普通策略更新复用已安装组件。该安装包绑定本机的路径、用户和游戏映像，另一台电脑需要重新生成并校验。

安装这一固定组件另需 **D 盘和 CPython 3.12**；普通源码界面的 Python 版本范围不代表该组件支持其他 Python 版本。它固定使用 `D:\CurrencyWarsInputBridge` 和 `D:\Codex\Temp\codex-agent-workflow`。先在用于安装和以后启动助手的 PowerShell 会话设置临时目录，再生成包：

```powershell
New-Item -ItemType Directory -Force D:\Codex\Temp | Out-Null
$env:TEMP = 'D:\Codex\Temp'
$env:TMP = $env:TEMP
.\.venv\Scripts\python.exe -B -X utf8 tools\build_input_bridge.py --game-path '游戏实际安装目录\StarRail.exe'
```

`--game-path` 必须指向本机真实游戏 EXE，生成过程会检查游戏签名和文件摘要。包生成后由新电脑上的 Codex 独立复核源码及包清单；复核完成才运行 `.\Install-InputBridge.ps1`。每次使用这个固定组件启动助手，也需从设置了上述 TEMP/TMP 的会话运行 `Start.ps1`。这些变量仅影响该 PowerShell 及其子进程，不修改 Windows 全局目录。没有 D 盘时当前固定组件不适用，不能直接复用本机组件包。

## 单屏悬浮控制

完整界面的“缩成浮窗”按钮可将同一个窗口缩成 216×40 的半透明深色状态条，显示状态点、当前运行状态和展开、退出按钮。拖动状态点移动窗口；点击 ↗ 展开完整面板，点击 × 释放自动输入并退出。完整面板提供最大化/还原和退出按钮。也可用 `.\.venv\Scripts\python.exe -B -X utf8 gui\launch.py --floating --chat-id <当前会话ID>` 直接打开浮窗。

浮窗默认 80% 不透明度，可用滑块调整到 40%～100%，数值越低越透明。按 F9 或“开启鼠标穿透”按钮切换锁定：穿透时鼠标点击送到下方游戏，按 F9 或备用 Ctrl+Alt+O 恢复浮窗操作。部分笔记本需 Fn+F9。也可从任务栏或 Alt+Tab 唤回助手，恢复完整可点击面板。界面按实际注册结果显示可用恢复键；没有可用全局恢复键时不能开启穿透。返回完整界面或退出会恢复窗口样式并释放热键；自动执行前会确认穿透，避免浮窗遮挡游戏点位。

点击状态文字可暂停、继续或开始，具体动作会随真实执行状态变化。助手的详细进度与更新时间放在完整界面；超过 60 秒没有进度报告时显示“暂未更新”。进度来自本次聊天写入的本地报告，不能代替执行器的真实运行状态。

开始或明确继续后，普通键盘、点击、滚轮或切到其他应用会暂时让出游戏输入；单纯移动鼠标不会暂停。全部键鼠释放并连续空闲 3 秒后，复核同一游戏和完整暂停身份，再通过原控制器切回本局游戏继续。持续按住键或鼠标按钮不会恢复；窗口转场时等待有效前台。F8、明确暂停、手动接管、停止、手柄活动和输入错误仍保持暂停。开关不会解除已有主动暂停；“查看助手后自动继续”仍保留当前助手窗口的身份核验。

F8 是独立暂停键，需点击状态文字明确继续。F9 切换鼠标穿透。Windows 置顶浮窗的实际显示取决于游戏显示模式；独占全屏遮住浮窗时，可使用游戏的无边框窗口模式。

完整面板提供“带教模式 / 全托管”切换按钮。开启时，进入战斗需要当前节点的单次确认；关闭时按全托管推进。设置保存在本机，切换模式不会启动执行器或解除已有暂停。带教时遇到卡点，应先说明实际现象、可能原因和可选处理方式，等用户指导；已有明确证据的普通决策由监督助手处理。

备战购买按目标槽位的实名、实价和原生画面独立核验，其他槽位未读全不会一律阻止已知目标。策略优先考虑实读对子、可上场过渡牌、小羁绊及前期经济成长，再考虑长线核心。当前星级、真实装备库存和适配读取仍不完整，需要监督助手和本机带教补齐；攻略推荐不代表已经拥有或佩戴。

## 界面可打开，自动操作仍有前置条件

项目不自动安装、启动或登录游戏。当前支持 1920×1080 和 3840×2160 的中文游戏客户区：截图统一为 1920×1080 识别，输入坐标映射到核验后的实际客户区；其他分辨率、语言和界面布局仍需重新校准。固定输入组件升级后需重新生成、独立审查并安装对应组件包。

公开仓库排除了截图、会话、账号配置、运行日志、既有验证记录和从个人游戏截图裁剪的商店、上场及战利品模板。商店识别需要用户在本机自行提供并核验 `tools/shop_reader_resources/` 中的 `SOURCES.json`、`names.json`、价格/空槽/推荐标记模板；缺少模板时返回错误或未知，不能据此自动购买。上场和战利品固定动作还依赖本机 `tools/free_lineup_resources/`、`tools/loot_resources/`；模板缺失或不匹配时不执行对应动作。这些资源尚没有自动校准入口。

开始和恢复还需要本机 Codex 审查当前核心源码，并写入有效的 `docs/RUNNER_READY.json`。该记录必须关联当前会话和源码 SHA256，包含真实独立审查的 PASS 身份和时间。安装脚本不会伪造或复用另一台机器的就绪记录；缺项时界面会显示未就绪，开始/恢复保持禁用。

新会话的正式审批通过执行器 `publish-ready --chat-id <ROOT> --review-file <独立审批JSON> --review-sha256 <文件SHA256>` 发布。ROOT汇总当前用户授权，独立审查者核当前完整运行时来源以及core/Rust审查；先确认所有已登记控制器退出，字段和命令见 [RUNNER_PROTOCOL](docs/RUNNER_PROTOCOL.md)。入口不启动游戏、不沿用旧实机结果，也不放宽Start检查。

需要 Codex 监督时，在该项目内开启 Codex 会话，并使用其实际会话身份启动，例如 `Start.ps1 -ChatId <当前会话ID>`。执行器会把投资、购买、装备和强化等判断转为有时限、与当前画面绑定的战略请求；监督代理通过固定 `decide` CLI 回答。GUI 留言只存入本地队列，没有内置模型连接或自动发送功能。

实际恢复前仍需要确认本机游戏窗口、输入权限、控制健康和手动交接。本轮已完成本机源码构建和界面按钮核验；尚未验证跨电脑安装后自动通关。最近一次超频带教已到“投资环境”三选一，但新执行器报告“只读截图没有同请求的新鲜回帧”后暂停退出，该问题尚未修复。实体 F8/F9，以及真实库存、星级、羁绊和装备适配读取也仍需本机验证。

## 安全控制和源码

暂停、接管、F8 和停止走独立控制通道；普通键鼠活动暂时让位并在释放后空闲恢复，手柄活动保持暂停。成功停止需要所属进程的创建身份和退出证据，不凭单个 PID 判断。运行目录只清理本次所属数据，未知或仍活跃的子进程会阻止清理。

- `gui/src`、`gui/ui`：原生 Rust/Tauri 界面。
- `tools/currency_wars_runner.py`：有界节点、状态与战略请求。
- `tools/currency_wars_control.py`：固定窗口的输入保护；入口核验固定源码哈希。
- `tools/currency_wars_perception.py`、`currency_wars_shop_reader.py`：本地识别。
- `tools/currency_wars_artifacts.py`：可移植运行目录；已有 Codex Agent Workflow 时保留其生命周期实现。
- `tools/check_install.py`：只读依赖检查，不加载输入控制器。
- `tools/currency_wars_update.py`、`currency_wars_source_guard.py`：规范仓库更新、启动活动保护和本机安装/构建指纹。

离线安装检查：

```powershell
.\.venv\Scripts\python.exe -B -X utf8 tools\check_install.py
.\.venv\Scripts\python.exe -B -X utf8 tools\test_public_packaging.py
.\.venv\Scripts\python.exe -B -X utf8 tools\test_currency_wars_update.py
```

本仓库未附项目开源许可证；公开可下载不代表授予额外再分发许可。第三方依赖保留各自许可，游戏资源不随仓库发布。
